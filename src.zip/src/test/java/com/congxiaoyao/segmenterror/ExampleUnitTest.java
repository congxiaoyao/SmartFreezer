package com.congxiaoyao.segmenterror;

import com.congxiaoyao.segmenterror.request.AnswerRequest;
import com.congxiaoyao.segmenterror.request.ArticleRequest;
import com.congxiaoyao.segmenterror.request.QuestionRequest;
import com.congxiaoyao.segmenterror.request.UserRequest;
import com.congxiaoyao.segmenterror.request.okhttp.MyOkHttp;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.response.beans.Page;
import com.congxiaoyao.segmenterror.response.exception.StatusException;

import org.junit.Test;

import rx.Observable;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class ExampleUnitTest {

    private static final Long id = 1010000006678575L;

    @Test
    public void addition_isCorrect() throws Exception {
//        assertEquals(4, 2 + 2);

        MyOkHttp.DEBUG = true;

//        SERetrofit.create(UserRequest.class)
//                .login("412961501@qq.com", "5677678")
//                .compose(ResponsePreProcess::dataToBean)
//                .subscribe(user -> {
//                    System.out.println(user);
//                }, throwable -> {
//                    System.out.println("error");
//                    StatusException exception = (StatusException) throwable;
//                    System.out.println(exception.getCode());
//                    System.out.println(exception.getReason());
//                });

        SERetrofit.create(AnswerRequest.class)
                .getAnswers(id, SERetrofit.TOKEN)
                .doOnNext(answerResponseListData -> {
                    System.out.println("total count = "+answerResponseListData.getData().size());
                })
                .compose(ResponsePreProcess::listDataToBeanList)
                .subscribe(answers -> {
                    Observable.from(answers).subscribe(answer -> System.out.println(answer.getOriginalText()));
                }, throwable -> {
                    System.out.println("error");
                    throwable.printStackTrace();
                });

        Thread.sleep(50000);
    }

    public void savePage(Page page) {
        System.out.println(page);
    }
}