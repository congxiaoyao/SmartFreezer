package com.congxiaoyao.segmenterror.response;

import com.congxiaoyao.segmenterror.response.beans.*;
import com.congxiaoyao.segmenterror.response.exception.ResponseException;
import com.congxiaoyao.segmenterror.response.exception.StatusException;
import com.google.gson.internal.LinkedTreeMap;
import rx.Observable;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import java.util.List;

/**
 * 服务器返回结果的预处理操作，我们将返回的json对象解析为{@link ResponseData}
 * 或{@link ResponseListData}或{@link ResponsePagedListData}类型的java对象，并将他们
 * 通过Observable发射出去，这里需要解决两个问题，{@link ResponseData}及其子类数据并不不是我们真正关心的
 * 并且我们希望能够实现统一的错误处理，于是类内的每一个public方法都会将Observable发送的数据
 * 转换为我们真正关心的数据(具体的ResponseBean的子类)如{@link Tag}、{@link Question}、{@link User}等等
 * 或者是关于这些对象的List,同时实现了错误处理并抛出相应异常以便统一在观察者代码中处理
 *
 * Created by congxiaoyao on 2016/7/7.
 */
public class ResponsePreProcess {

    /**
     * 返回一个Transformer，此Transformer实现了
     * 将泛型为{@link ResponsePagedListData<T>}的Observable 转化为 泛型为{@link T}的Observable的功能
     * 在转换的过程中，首先做错误处理，之后回调 {@param savePage}保存分页信息
     * 然后通过flatMap操作去转化Observable，最终指定subscribeOn并返回
     * @param savePage
     * @param <T>
     * @return 具有ResponsePagedListData->Bean能力的Transformer
     */
    public static <T extends ResponseBean> Observable.Transformer
            <ResponsePagedListData<T>, T> pagedListDataToBean(Action1<Page> savePage) {
        return pagedListDataObservable -> pagedListDataObservable.doOnNext(
                pagedListData -> {
                    //检查状态码
                    checkStatus(pagedListData);
                    //判断list是否为空
                    checkListNull(pagedListData.getData().getRows());
                    //经过flat之后page就被舍弃了，所以在这里做下保存操作
                    savePage.call(pagedListData.getData().getPage());
                })
                //将ListData<T>flat成T
                .flatMap(pagedListData -> Observable.from(pagedListData.getData().getRows()))
                //设置请求的线程
                .subscribeOn(Schedulers.io());
    }

    /**
     * 跟上一个套路一样 只是将泛型为{@link ResponsePagedListData<T>}的Observable
     * 转化为 泛型为{@link List<T>}的Observable 分页信息处理与上一个一样 同时具有错误处理功能
     *
     * @param savePage
     * @param <T>
     * @return
     */
    public static <T extends ResponseBean> Observable.Transformer
            <ResponsePagedListData<T>, List<T>> pagedListDataToBeanList(Action1<Page> savePage) {
        return pagedListDataObservable -> pagedListDataObservable.doOnNext(
                pagedListData -> {
                    //检查状态码
                    checkStatus(pagedListData);
                    //判断list是否为空
                    checkListNull(pagedListData.getData().getRows());
                    //经过flat之后page就被舍弃了，所以在这里做下保存操作
                    savePage.call(pagedListData.getData().getPage());
                })
                //将ListData<T>map成List<T>
                .map(pagedListData -> pagedListData.getData().getRows())
                //设置请求的线程
                .subscribeOn(Schedulers.io());
    }

    /**
     * 这其实相当于一个Transformer内的回调函数的实现
     * 直接实现 将泛型为{@link ResponseListData<T>}的Observable 转化为 泛型为{@link T}的Observable的功能
     * 因为不需要保存分页信息，所以采用这种设计可以直接在java8中用两个冒号调用它
     * 同样也会做错误处理和线程指定
     *
     * @param listDataObservable
     * @param <T>
     * @return 泛型为一种具体Bean类型的Observable
     */
    public static <T extends ResponseBean> Observable<T> listDataToBean
    (Observable<ResponseListData<T>> listDataObservable) {
        return listDataObservable.doOnNext(
                listData -> {
                    //检查状态码
                    checkStatus(listData);
                    //判断list是否为空
                    checkListNull(listData.getData());
                })
                //将ListData<T>flat成T
                .flatMap(listData -> Observable.from(listData.getData()))
                //设置请求的线程
                .subscribeOn(Schedulers.io());
    }

    /**
     * 将泛型为{@link ResponseListData<T>}的Observable 转化为 泛型为{@link List<T>}的Observable
     * 惯例错误处理和线程指定
     * @param listDataObservable
     * @param <T>
     * @return
     */
    public static <T extends ResponseBean> Observable<List<T>> listDataToBeanList
    (Observable<ResponseListData<T>> listDataObservable) {
        return listDataObservable.doOnNext(
                listData -> {
                    //检查状态码
                    checkStatus(listData);
                    //判断list是否为空
                    checkListNull(listData.getData());
                })
                //将ListData<T>map成List<T>
                .map(listData -> listData.getData())
                //设置请求的线程
                .subscribeOn(Schedulers.io());
    }

    /**
     * 给定泛型为{@link ResponseData<T>}的Observable 返回 泛型为{@link T}的Observable
     * 当然肯定还有错误处理和线程指定
     *
     * @param dataObservable
     * @param <T>
     * @return
     */
    public static <T> Observable<T> dataToBean(Observable<ResponseData<T>> dataObservable) {
        return dataObservable.doOnNext(
                data -> {
                    //检查状态码
                    checkStatus(data);
                    //判断data是否为空
                    checkObjectNull(data.getData());
                })
                //将ListData<T>map成T
                .map(data -> data.getData())
                //设置请求的线程
                .subscribeOn(Schedulers.io());
    }

    /**
     * 判断list是否为null或没有数据
     * 如果为null或没有数据则抛出异常
     *
     * @param list
     * @param <T>
     */
    private static <T> void checkListNull(List<T> list) {
        if (list == null) {
            throw new ResponseException(ResponseException.MSG_NULL_DATA_ERROR);
        }
        if (list.size() == 0) {
            throw new ResponseException(ResponseException.MSG_NULL_DATA_ERROR);
        }
    }

    /**
     *
     * 判断一个Object也就是{@link ResponseListData}中的data是否为null或没有数据
     * 如果为null或没有数据则抛出异常
     *
     * @param data
     * @param <T>
     */
    private static <T> void checkObjectNull(T data) {
        if (data == null) {
            throw new ResponseException(ResponseException.MSG_NULL_DATA_ERROR);
        }
        if (data.getClass() == LinkedTreeMap.class) {
            throw new ResponseException(ResponseException.MSG_NULL_DATA_ERROR);
        }
    }

    /**
     * 判断data的状态码是否为请求成功
     * 如果不成功抛出异常
     *
     * @param data
     * @param <T>
     */
    private static <T> void checkStatus(ResponseData<T> data) {
        if (!data.isSuccess())
            throw new StatusException(ResponseException.MSG_STATUS_ERROR,
                    data.getCode(), data.getMessage());
    }
}