package com.congxiaoyao.segmenterror.response.beans;

public class SimpleUser implements ResponseBean {

    private String name;
    private String mail;
    private String slug;
    private String id;
    private String url;
    private String rank;
    private String avatarUrl;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    @Override
    public String toString() {
        return "SimpleUser{" +
                "name='" + name + '\'' +
                ", mail='" + mail + '\'' +
                ", slug='" + slug + '\'' +
                ", id='" + id + '\'' +
                ", url='" + url + '\'' +
                ", rank='" + rank + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                '}';
    }
}
