package com.congxiaoyao.segmenterror.response;

import com.congxiaoyao.segmenterror.response.beans.ResponseBean;

import java.util.List;

/**
 * 区别于{@link ResponsePagedListData} 这个也代表了列表数据，但是不带page对象
 * 详情见{@link ResponsePagedListData}
 *
 * Created by congxiaoyao on 2016/7/7.
 */
public class ResponseListData<T extends ResponseBean> extends ResponseData<List<T>> {

}
