package com.congxiaoyao.segmenterror.response.beans;

import java.util.ArrayList;

/**
 * Created by congxiaoyao on 2016/7/9.
 */
public class Question implements ResponseBean {

    private Long id;
    private String title;
    private String url;
    private int answers;            //回答数
    private int votes;              //投票数
    private Long created;           //创建时间(秒)
    private String createdDate;     //提问时间 如 20分钟前
    private SimpleUser user;        //提问者
    private ArrayList<Tag> tags;    //问题分类的标签
    private int comments;           //评论数
    private int followers;          //关注数
    private int bookmarks;          //收藏数
    private boolean canEdit;
    private boolean canHate;
    private boolean canLike;
    private boolean isAccepted;
    private boolean isBookmarked;
    private boolean isClosed;
    private boolean isFollowed;
    private boolean isHated;
    private boolean isLiked;
    private String excerpt;         //问题预览
    private String originalText;    //markDown格式的问题详情
    private String parsedText;      //html格式的问题详情

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getAnswers() {
        return answers;
    }

    public void setAnswers(int answers) {
        this.answers = answers;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public Long getCreated() {
        return created;
    }

    public void setCreated(Long created) {
        this.created = created;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public SimpleUser getUser() {
        return user;
    }

    public void setUser(SimpleUser user) {
        this.user = user;
    }

    public ArrayList<Tag> getTags() {
        return tags;
    }

    public void setTags(ArrayList<Tag> tags) {
        this.tags = tags;
    }

    public int getComments() {
        return comments;
    }

    public void setComments(int comments) {
        this.comments = comments;
    }

    public int getFollowers() {
        return followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public int getBookmarks() {
        return bookmarks;
    }

    public void setBookmarks(int bookmarks) {
        this.bookmarks = bookmarks;
    }

    public boolean isCanEdit() {
        return canEdit;
    }

    public void setCanEdit(boolean canEdit) {
        this.canEdit = canEdit;
    }

    public boolean isCanHate() {
        return canHate;
    }

    public void setCanHate(boolean canHate) {
        this.canHate = canHate;
    }

    public boolean isCanLike() {
        return canLike;
    }

    public void setCanLike(boolean canLike) {
        this.canLike = canLike;
    }

    public boolean isAccepted() {
        return isAccepted;
    }

    public void setAccepted(boolean accepted) {
        isAccepted = accepted;
    }

    public boolean isBookmarked() {
        return isBookmarked;
    }

    public void setBookmarked(boolean bookmarked) {
        isBookmarked = bookmarked;
    }

    public boolean isClosed() {
        return isClosed;
    }

    public void setClosed(boolean closed) {
        isClosed = closed;
    }

    public boolean isFollowed() {
        return isFollowed;
    }

    public void setFollowed(boolean followed) {
        isFollowed = followed;
    }

    public boolean isHated() {
        return isHated;
    }

    public void setHated(boolean hated) {
        isHated = hated;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }

    public String getExcerpt() {
        return excerpt;
    }

    public void setExcerpt(String excerpt) {
        this.excerpt = excerpt;
    }

    public String getOriginalText() {
        return originalText;
    }

    public void setOriginalText(String originalText) {
        this.originalText = originalText;
    }

    public String getParsedText() {
        return parsedText;
    }

    public void setParsedText(String parsedText) {
        this.parsedText = parsedText;
    }

    @Override
    public String toString() {
        return "Question{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", answers=" + answers +
                ", votes=" + votes +
                ", created=" + created +
                ", createdDate='" + createdDate + '\'' +
                ", user=" + user +
                ", tags=" + tags +
                ", comments=" + comments +
                ", followers=" + followers +
                ", bookmarks=" + bookmarks +
                ", canEdit=" + canEdit +
                ", canHate=" + canHate +
                ", canLike=" + canLike +
                ", isAccepted=" + isAccepted +
                ", isBookmarked=" + isBookmarked +
                ", isClosed=" + isClosed +
                ", isFollowed=" + isFollowed +
                ", isHated=" + isHated +
                ", isLiked=" + isLiked +
                ", excerpt='" + excerpt + '\'' +
                ", originalText='" + originalText + '\'' +
                ", parsedText='" + parsedText + '\'' +
                '}';
    }
}
