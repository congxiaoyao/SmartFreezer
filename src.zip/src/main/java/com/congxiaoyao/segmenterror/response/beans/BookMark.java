package com.congxiaoyao.segmenterror.response.beans;

import java.util.List;

/**
 * 代表了收藏夹中的一条记录
 *
 * Created by congxiaoyao on 2016/7/17.
 */
public class BookMark implements ResponseBean {

    public static final String TYPE_ARTICLE = "article";
    public static final String TYPE_QUESTION = "question";

    private Long id;
    private String url;
    private String title;
    private String createdDate;
    private SimpleUser user;
    private List<Tag> tags;
    private int votes;
    private String viewsWord;
    private int bookmarks;
    private String type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public SimpleUser getUser() {
        return user;
    }

    public void setUser(SimpleUser user) {
        this.user = user;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public String getViewsWord() {
        return viewsWord;
    }

    public void setViewsWord(String viewsWord) {
        this.viewsWord = viewsWord;
    }

    public int getBookmarks() {
        return bookmarks;
    }

    public void setBookmarks(int bookmarks) {
        this.bookmarks = bookmarks;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "BookMark{" +
                "id=" + id +
                ", url='" + url + '\'' +
                ", title='" + title + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", user=" + user +
                ", tags=" + tags +
                ", votes=" + votes +
                ", viewsWord='" + viewsWord + '\'' +
                ", bookmarks=" + bookmarks +
                ", type='" + type + '\'' +
                '}';
    }
}
