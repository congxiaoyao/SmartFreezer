package com.congxiaoyao.segmenterror.response.beans;

/**
 * 邀请我回答的问题 道理同{@link AnsweredQuestion}一样
 *
 * Created by congxiaoyao on 2016/7/17.
 */
public class InvitedQuestion implements ResponseBean {

    private String createdDate;
    private Long id;
    private boolean isAnswered;
    private Question question;
    private SimpleUser triggerUser;     //提问者

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isAnswered() {
        return isAnswered;
    }

    public void setAnswered(boolean answered) {
        isAnswered = answered;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public SimpleUser getTriggerUser() {
        return triggerUser;
    }

    public void setTriggerUser(SimpleUser triggerUser) {
        this.triggerUser = triggerUser;
    }

    @Override
    public String toString() {
        return "InvitedQuestion{" +
                "createdDate='" + createdDate + '\'' +
                ", id=" + id +
                ", isAnswered=" + isAnswered +
                ", question=" + question +
                ", triggerUser=" + triggerUser +
                '}';
    }
}
