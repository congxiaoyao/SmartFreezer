package com.congxiaoyao.segmenterror.response.beans;

/**
 * Created by congxiaoyao on 2016/7/16.
 */
public class Comment implements ResponseBean {

    private Long id;
    private Long userId;
    private Long objectId;
    private boolean canDelete;
    private boolean canEdit;
    private SimpleUser replyUser;
    private SimpleUser user;
    private String parsedText;
    private String originalText;
    private String createdDate;
    private boolean isHated;
    private boolean isLiked;
    private int votes;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public boolean isCanDelete() {
        return canDelete;
    }

    public void setCanDelete(boolean canDelete) {
        this.canDelete = canDelete;
    }

    public boolean isCanEdit() {
        return canEdit;
    }

    public void setCanEdit(boolean canEdit) {
        this.canEdit = canEdit;
    }

    public SimpleUser getReplyUser() {
        return replyUser;
    }

    public void setReplyUser(SimpleUser replyUser) {
        this.replyUser = replyUser;
    }

    public SimpleUser getUser() {
        return user;
    }

    public void setUser(SimpleUser user) {
        this.user = user;
    }

    public String getParsedText() {
        return parsedText;
    }

    public void setParsedText(String parsedText) {
        this.parsedText = parsedText;
    }

    public String getOriginalText() {
        return originalText;
    }

    public void setOriginalText(String originalText) {
        this.originalText = originalText;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public boolean isHated() {
        return isHated;
    }

    public void setHated(boolean hated) {
        isHated = hated;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", userId=" + userId +
                ", objectId=" + objectId +
                ", canDelete=" + canDelete +
                ", canEdit=" + canEdit +
                ", replyUser=" + replyUser +
                ", user=" + user +
                ", parsedText='" + parsedText + '\'' +
                ", originalText='" + originalText + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", isHated=" + isHated +
                ", isLiked=" + isLiked +
                ", votes=" + votes +
                '}';
    }
}
