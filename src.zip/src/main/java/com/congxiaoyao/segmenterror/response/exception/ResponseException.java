package com.congxiaoyao.segmenterror.response.exception;

/**
 * 定义了几种可能发生的请求网络接口所产生的错误，用于统一处理
 * 下面详细介绍下几种message的意义和可能产生的情况
 *
 * {@link ResponseException#MSG_CONVERT_ERROR}
 * 解析json数据失败会产生这种异常
 * 一般来说，如果服务器没问题的话，就是请求了错误的网址或写错了返回类型，开发时会常遇到
 *
 * {@link ResponseException#MSG_NULL_DATA_ERROR}
 * 返回的json中的真正代表数据的字段没有内容，可能是null或者是只有一对括号，如果是列表数据
 * 也会检查其rows字段(列表项)是否为空
 * 一般也不会错，可能会没数据这倒是真的，所以当没数据的时候也作为异常捕获下来了方便处理
 *
 * {@link ResponseException#MSG_STATUS_ERROR}
 * 返回的json数据中的status为1
 * 一般会使用子类{@link StatusException}来代表这种异常
 *
 * {@link ResponseException#MSG_NULL_RESPONSE_ERROR}
 * 返回的数据长度为0也就是根本没有任何json字串被返回会抛出此异常
 * 一般来说是由服务器问题导致的，也有可能因为网络原因
 *
 * {@link ResponseException#MSG_NULL_NETWORK_ERROR}
 * 无网络连接 不解释
 *
 * Created by congxiaoyao on 2016/7/7.
 */
public class ResponseException extends RuntimeException {

    public static final String MSG_CONVERT_ERROR = "MSG_CONVERT_ERROR";
    public static final String MSG_NULL_DATA_ERROR = "MSG_NULL_DATA_ERROR";
    public static final String MSG_STATUS_ERROR = "MSG_STATUS_ERROR";
    public static final String MSG_NULL_RESPONSE_ERROR = "MSG_NULL_RESPONSE_ERROR";
    public static final String MSG_NULL_NETWORK_ERROR = "MSG_NULL_NETWORK_ERROR";

    public ResponseException(String message) {
        super(message);
    }
}
