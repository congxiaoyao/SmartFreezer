package com.congxiaoyao.segmenterror.response.beans;

/**
 * Created by congxiaoyao on 2016/7/10.
 */
public class Answer implements ResponseBean{

    public static final String TYPE_ACCEPTED = "accepted";
    public static final String TYPE_AVAILABLE = "available";
    public static final String TYPE_IGNORED = "ignored";

    private Long id;
    private String url;
    private String shortUrl;
    private String originalText;
    private String parsedText;

    private boolean canAccept;
    private boolean canDelete;
    private boolean canEdit;
    private boolean canIgnore;

    private SimpleUser user;        //回答者
    private int comments;           //评论数
    private boolean isHated;
    private boolean isLiked;
    private boolean isBookmarked;
    private String createdDate;     //回答时间

    private int votes;
    private String type;            //类型 三种常量中的一种

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getShortUrl() {
        return shortUrl;
    }

    public void setShortUrl(String shortUrl) {
        this.shortUrl = shortUrl;
    }

    public String getOriginalText() {
        return originalText;
    }

    public void setOriginalText(String originalText) {
        this.originalText = originalText;
    }

    public String getParsedText() {
        return parsedText;
    }

    public void setParsedText(String parsedText) {
        this.parsedText = parsedText;
    }

    public boolean isCanAccept() {
        return canAccept;
    }

    public void setCanAccept(boolean canAccept) {
        this.canAccept = canAccept;
    }

    public boolean isCanDelete() {
        return canDelete;
    }

    public void setCanDelete(boolean canDelete) {
        this.canDelete = canDelete;
    }

    public boolean isCanEdit() {
        return canEdit;
    }

    public void setCanEdit(boolean canEdit) {
        this.canEdit = canEdit;
    }

    public boolean isCanIgnore() {
        return canIgnore;
    }

    public void setCanIgnore(boolean canIgnore) {
        this.canIgnore = canIgnore;
    }

    public SimpleUser getUser() {
        return user;
    }

    public void setUser(SimpleUser user) {
        this.user = user;
    }

    public int getComments() {
        return comments;
    }

    public void setComments(int comments) {
        this.comments = comments;
    }

    public boolean isHated() {
        return isHated;
    }

    public void setHated(boolean hated) {
        isHated = hated;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }

    public boolean isBookmarked() {
        return isBookmarked;
    }

    public void setBookmarked(boolean bookmarked) {
        isBookmarked = bookmarked;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Answer{" +
                "id=" + id +
                ", url='" + url + '\'' +
                ", shortUrl='" + shortUrl + '\'' +
                ", originalText='" + originalText + '\'' +
                ", parsedText='" + parsedText + '\'' +
                ", canAccept=" + canAccept +
                ", canDelete=" + canDelete +
                ", canEdit=" + canEdit +
                ", canIgnore=" + canIgnore +
                ", user=" + user +
                ", comments=" + comments +
                ", isHated=" + isHated +
                ", isLiked=" + isLiked +
                ", isBookmarked=" + isBookmarked +
                ", createdDate='" + createdDate + '\'' +
                ", votes=" + votes +
                ", type='" + type + '\'' +
                '}';
    }
}
