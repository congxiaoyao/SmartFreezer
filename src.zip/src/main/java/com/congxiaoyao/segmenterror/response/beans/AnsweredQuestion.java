package com.congxiaoyao.segmenterror.response.beans;

/**
 * 在我的回答界面中，为了获取我回答过的问题的列表，
 * 请求的返回值是ResponsePagedListData<AnsweredQuestion>类型
 * 所以此类代表了已回答的问题简介
 * <p>
 * Created by congxiaoyao on 2016/7/11.
 */
public class AnsweredQuestion implements ResponseBean {

    private Long id;
    private String title;
    private boolean isAccepted;
    private int votes;
    private String excerpt;
    private String createdDate;
    private Question question;
    private SimpleUser user;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isAccepted() {
        return isAccepted;
    }

    public void setAccepted(boolean accepted) {
        isAccepted = accepted;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public String getExcerpt() {
        return excerpt;
    }

    public void setExcerpt(String excerpt) {
        this.excerpt = excerpt;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public SimpleUser getUser() {
        return user;
    }

    public void setUser(SimpleUser user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "AnsweredQuestion{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", isAccepted=" + isAccepted +
                ", votes=" + votes +
                ", excerpt='" + excerpt + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", question=" + question +
                ", user=" + user +
                '}';
    }
}
