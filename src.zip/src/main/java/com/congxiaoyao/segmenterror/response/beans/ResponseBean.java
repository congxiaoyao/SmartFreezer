package com.congxiaoyao.segmenterror.response.beans;

/**
 * 用于标示哪些类是代表返回的json数据中data字段里具体数据的类
 *
 * Created by congxiaoyao on 2016/7/16.
 */
public interface ResponseBean {
}
