package com.congxiaoyao.segmenterror.response.exception;

import android.content.Context;

import com.congxiaoyao.segmenterror.Me;
import com.congxiaoyao.segmenterror.request.retrofit2.adapter.rxjava.HttpException;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

/**
 * Created by congxiaoyao on 2016/9/8.
 */
public class ExceptionDispatcher {

    private IExceptionHandler exceptionHandler;

    public void dispatchException(Throwable throwable) {

        //分发错误之前回调下
        exceptionHandler.onDispatchException(throwable);

        //如果是状态码错误
        if (throwable instanceof StatusException) {
            StatusException exception = (StatusException) throwable;
            boolean handled = false;
            switch (exception.getCode()) {
                case StatusException.CODE_LOGIN_ERROR:
                    handled = exceptionHandler.onLoginError(exception.getReason());
                    break;
                case StatusException.CODE_UN_LOGIN:
                    handled = exceptionHandler.onUnLogin(exception.getReason());
                    break;
            }
            if (!handled) {
                handled = exceptionHandler.onStatusError(exception);
            }
            if (!handled) {
                exceptionHandler.onResponseError(exception);
            }
            return;
        }

        //如果是已知的ResponseException
        if (throwable instanceof ResponseException) {
            ResponseException exception = (ResponseException) throwable;
            boolean handled = false;
            switch (exception.getMessage()) {
                case ResponseException.MSG_CONVERT_ERROR:
                    handled = exceptionHandler.onConvertError(ResponseException.MSG_CONVERT_ERROR);
                    break;
                case ResponseException.MSG_NULL_DATA_ERROR:
                    handled = exceptionHandler.onNullDataError(ResponseException.MSG_NULL_DATA_ERROR);
                    break;
                case ResponseException.MSG_NULL_NETWORK_ERROR:
                    handled = exceptionHandler.onNullNetworkError(ResponseException.MSG_NULL_NETWORK_ERROR);
                    break;
                case ResponseException.MSG_NULL_RESPONSE_ERROR:
                    handled = exceptionHandler.onNullResponseError(ResponseException.MSG_NULL_RESPONSE_ERROR);
                    break;
                case ResponseException.MSG_STATUS_ERROR:
                    handled = exceptionHandler.onStatusError((StatusException) exception);
                    break;
            }
            if (!handled) {
                exceptionHandler.onResponseError(exception);
            }
            return;
        }

        //如果网络超时
        if (throwable instanceof SocketTimeoutException) {
            exceptionHandler.onTimeoutError((SocketTimeoutException) throwable);
            return;
        }

        //如果未知域名错误
        if (throwable instanceof UnknownHostException) {
            exceptionHandler.onUnknowHostError((UnknownHostException) throwable);
            return;
        }

        //主机维护了估计
        if (throwable instanceof HttpException) {
            exceptionHandler.onHttpError((HttpException) throwable);
            return;
        }

        //不是已知的错误
        exceptionHandler.unKnowError(throwable);
    }

    public void setExceptionHandler(IExceptionHandler exceptionHandler) {
        this.exceptionHandler = exceptionHandler;
    }

    public String getTokenOrDispatchException(Context context) {
        String token = Me.token(context);
        if (token == null || token.equals("")) {
            dispatchException(new StatusException(StatusException.MSG_STATUS_ERROR,
                    StatusException.CODE_UN_LOGIN, "请登录"));
            return null;
        }
        return token;
    }
}
