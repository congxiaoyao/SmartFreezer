package com.congxiaoyao.segmenterror.response.beans;

/**
 * 代表了一个收藏夹
 *
 * Created by congxiaoyao on 2016/7/17.
 */
public class Archive implements ResponseBean {

    private Long id;
    private String title;
    private String description;
    private int isPrivate;          //访问权限 0表示公开
    private int num;                //有几条记录

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIsPrivate() {
        return isPrivate;
    }

    public void setIsPrivate(int isPrivate) {
        this.isPrivate = isPrivate;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "Archive{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", isPrivate=" + isPrivate +
                ", num=" + num +
                '}';
    }
}
