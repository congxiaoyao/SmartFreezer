package com.congxiaoyao.segmenterror.response.beans;

/**
 * 登陆后返回的信息，除了简单的用户信息之外，还会带有一个token用于后续的请求
 *
 * Created by congxiaoyao on 2016/7/9.
 */
public class LoginInfo implements ResponseBean {

    private String token;
    private SimpleUser user;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public SimpleUser getUser() {
        return user;
    }

    public void setUser(SimpleUser user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "LoginInfo{" +
                "token='" + token + '\'' +
                ", user=" + user +
                '}';
    }


}
