package com.congxiaoyao.segmenterror.response.beans;

import java.util.List;

/**
 * Created by congxiaoyao on 2016/8/15.
 */
public class Notification implements ResponseBean {

    private String id;
    private String title;               //标题
    private String url;
    private String sentence;            //感觉这个可以不用管
    private String date;                //日期 3月29日
    private String viewed;              //是否被查看了 1是查看了应该 0是没查看??
    private String currentStatus;       //当前状态 已经发现了有 deleted available
    private NotifyObject object;        //大概是说这是个什么东西 比如这是一个问题的通知或者是成就的通知等
    private NotifyTarget target;        //通知的具体内容比如谁回答了问题 谁评论了你的答案

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSentence() {
        return sentence;
    }

    public void setSentence(String sentence) {
        this.sentence = sentence;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getViewed() {
        return viewed;
    }

    public void setViewed(String viewed) {
        this.viewed = viewed;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public NotifyObject getObject() {
        return object;
    }

    public void setObject(NotifyObject object) {
        this.object = object;
    }

    public NotifyTarget getTarget() {
        return target;
    }

    public void setTarget(NotifyTarget target) {
        this.target = target;
    }

    @Override
    public String toString() {
        return "Notification{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", sentence='" + sentence + '\'' +
                ", date='" + date + '\'' +
                ", viewed='" + viewed + '\'' +
                ", currentStatus='" + currentStatus + '\'' +
                ", object=" + object +
                ", target=" + target +
                '}';
    }

    public static class NotifyTarget {
        private String word;        //目测是%怎么怎么你了
        private List<SimpleUser> users;    //应该就是%对应的内容

        public NotifyTarget() {

        }

        public NotifyTarget(String word, List<SimpleUser> users) {
            this.word = word;
            this.users = users;
        }

        public List<SimpleUser> getUsers() {
            return users;
        }

        public void setUsers(List<SimpleUser> users) {
            this.users = users;
        }

        public String getWord() {
            return word;
        }

        public void setWord(String word) {
            this.word = word;
        }

        @Override
        public String toString() {
            return "NotifyTarget{" +
                    "word='" + word + '\'' +
                    ", users=" + users +
                    '}';
        }
    }

    public static class NotifyObject {

        private String type;        //目测type的值有badge、question、users maybe有answer??
        private String id;          //通过id可以找到他们

        public NotifyObject() {

        }

        public NotifyObject(String type, String id) {
            this.type = type;
            this.id = id;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        @Override
        public String toString() {
            return "NotifyObject{" +
                    "id='" + id + '\'' +
                    ", type='" + type + '\'' +
                    '}';
        }
    }
}
