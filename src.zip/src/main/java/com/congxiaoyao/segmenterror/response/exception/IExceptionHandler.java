package com.congxiaoyao.segmenterror.response.exception;

import com.congxiaoyao.segmenterror.request.retrofit2.adapter.rxjava.HttpException;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

/**
 * Created by congxiaoyao on 2016/8/25.
 */
public interface IExceptionHandler {

    void onDispatchException(Throwable throwable);

    void onResponseError(ResponseException exception);

    void onTimeoutError(SocketTimeoutException exception);

    void onUnknowHostError(UnknownHostException exception);

    void onHttpError(HttpException exception);

    boolean onConvertError(String msg);

    boolean onNullDataError(String msg);

    boolean onStatusError(StatusException exception);

    boolean onNullResponseError(String msg);

    boolean onNullNetworkError(String msg);

    boolean unKnowError(Throwable throwable);

    boolean onUnLogin(String reason);

    boolean onLoginError(String reason);
}
