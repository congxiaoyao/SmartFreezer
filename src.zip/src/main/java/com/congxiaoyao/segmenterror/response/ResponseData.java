package com.congxiaoyao.segmenterror.response;

/**
 * 所有的segmentfault的api返回的数据都是形如 {@link ResponseData} 的格式
 * 不同的请求，返回的data字段的类型可能不同，所以这里直接使用泛型代替
 *
 * Created by congxiaoyao on 2016/7/7.
 */
public class ResponseData<T> {

    private int status;
    private T data;
    private String message;
    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return status == 0;
    }

    @Override
    public String toString() {
        return "ResponseData{" +
                "status=" + status +
                ", data=" + data +
                ", message='" + message + '\'' +
                ", code='" + code + '\'' +
                '}';
    }

}