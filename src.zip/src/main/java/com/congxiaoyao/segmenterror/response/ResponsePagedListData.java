package com.congxiaoyao.segmenterror.response;


import com.congxiaoyao.segmenterror.response.beans.ResponseBean;

/**
 * 这个类用于存放关于{@code T}类型的list的数据，同时带有一个page对象
 * 多继承了一步主要为了写起来会短一点，看起来也会舒服一点
 * 毕竟泛型里面还有一个带泛型的类型总让人觉得难受，而且这样表达的思路也更清晰
 * <p>
 * Created by congxiaoyao on 2016/7/7.
 */
public class ResponsePagedListData<T extends ResponseBean>
        extends ResponseData<PagedBeanList<T>> {
}
