package com.congxiaoyao.segmenterror.response.beans;

import com.google.gson.internal.LinkedTreeMap;

import java.util.ArrayList;

/**
 * Created by congxiaoyao on 2016/7/17.
 */
public class Article implements ResponseBean {

    private Long id;
    private String url;
    private String title;
    private int votes;          //投票数(点赞数)
    private String createdDate; //创建时间
    private int comments;       //评论数
    private String excerpt;     //预览
    private String currentStatus;
    private int bookmarks;
    private LinkedTreeMap<String, String> blog;
    private SimpleUser user;    //作者
    private ArrayList<Tag> tags;//文章的标签
    private boolean isBookmarked;
    private boolean isHated;
    private boolean isLiked;
    private String originalText;
    private String parsedText;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public int getComments() {
        return comments;
    }

    public void setComments(int comments) {
        this.comments = comments;
    }

    public String getExcerpt() {
        return excerpt;
    }

    public void setExcerpt(String excerpt) {
        this.excerpt = excerpt;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public int getBookmarks() {
        return bookmarks;
    }

    public void setBookmarks(int bookmarks) {
        this.bookmarks = bookmarks;
    }

    public LinkedTreeMap<String, String> getBlog() {
        return blog;
    }

    public void setBlog(LinkedTreeMap<String, String> blog) {
        this.blog = blog;
    }

    public SimpleUser getUser() {
        return user;
    }

    public void setUser(SimpleUser user) {
        this.user = user;
    }

    public ArrayList<Tag> getTags() {
        return tags;
    }

    public void setTags(ArrayList<Tag> tags) {
        this.tags = tags;
    }

    public boolean isBookmarked() {
        return isBookmarked;
    }

    public void setBookmarked(boolean bookmarked) {
        isBookmarked = bookmarked;
    }

    public boolean isHated() {
        return isHated;
    }

    public void setHated(boolean hated) {
        isHated = hated;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }

    public String getOriginalText() {
        return originalText;
    }

    public void setOriginalText(String originalText) {
        this.originalText = originalText;
    }

    public String getParsedText() {
        return parsedText;
    }

    public void setParsedText(String parsedText) {
        this.parsedText = parsedText;
    }

    @Override
    public String toString() {
        return "Article{" +
                "id=" + id +
                ", url='" + url + '\'' +
                ", title='" + title + '\'' +
                ", votes=" + votes +
                ", createdDate='" + createdDate + '\'' +
                ", comments=" + comments +
                ", excerpt='" + excerpt + '\'' +
                ", currentStatus='" + currentStatus + '\'' +
                ", bookmarks=" + bookmarks +
                ", blog=" + blog +
                ", user=" + user +
                ", tags=" + tags +
                ", isBookmarked=" + isBookmarked +
                ", isHated=" + isHated +
                ", isLiked=" + isLiked +
                ", originalText='" + originalText + '\'' +
                ", parsedText='" + parsedText + '\'' +
                '}';
    }
}
