package com.congxiaoyao.segmenterror.response.beans;

/**
 * Created by congxiaoyao on 2016/7/7.
 */
public class Tag implements ResponseBean {

    private String name;
    private String url;
    private Long id;
    private String thumbnailUrl;    //图标地址(大图)
    private boolean isFollowed;     //是否关注
    private String excerpt;         //简介

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public boolean isFollowed() {
        return isFollowed;
    }

    public void setFollowed(boolean followed) {
        isFollowed = followed;
    }

    public String getExcerpt() {
        return excerpt;
    }

    public void setExcerpt(String excerpt) {
        this.excerpt = excerpt;
    }

    @Override
    public String toString() {
        return "Tag{" +
                "name='" + name + '\'' +
                ", url='" + url + '\'' +
                ", id=" + id +
                ", thumbnailUrl='" + thumbnailUrl + '\'' +
                ", isFollowed=" + isFollowed +
                ", excerpt='" + excerpt + '\'' +
                '}';
    }
}
