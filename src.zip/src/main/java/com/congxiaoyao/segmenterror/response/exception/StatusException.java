package com.congxiaoyao.segmenterror.response.exception;

/**
 * 服务器返回数据后，json中status的值为1的一种特殊的异常情况
 * 此异常保存了出错时服务器返回的错误信息 有错误码和错误原因两个字段
 * 一般情况下此异常的message为{@link ResponseException#MSG_STATUS_ERROR}
 *
 * Created by congxiaoyao on 2016/7/9.
 */
public class StatusException extends ResponseException {

    public static final int CODE_UN_LOGIN = 3000000;                //未登录
    public static final int CODE_LOGIN_ERROR = 1390902;             //用户名密码错误
    //TODO 将这个情况在ExceptionHandler中做详细处理
    public static final int CODE_USER_NOT_EXIST = 2030001;          //用户不存在
    //TODO 将这个情况在ExceptionHandler中做详细处理
    private static final int CODE_QUESTION_NOT_EXIST = 2010005;     //问题不存在

    private int code;
    private String reason;

    public StatusException(String message, int code,String reason) {
        super(message);
        this.code = code;
        this.reason = reason;
    }

    public int getCode() {
        return code;
    }

    public String getReason() {
        return reason;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "StatusException{" +
                "code=" + code +
                ", reason='" + reason + '\'' +
                '}';
    }
}
