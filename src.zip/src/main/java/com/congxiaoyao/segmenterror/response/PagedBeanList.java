package com.congxiaoyao.segmenterror.response;

import com.congxiaoyao.segmenterror.response.beans.Page;
import com.congxiaoyao.segmenterror.response.beans.ResponseBean;

import java.util.List;

/**
 * 服务器会返回关于某个信息的列表，比如问题列表、文章列表等等
 * 这个时候，其返回的json中的data字段是某种数据的列表同时带一个page对象
 * 这个类就是为了fit这种情况，将不同的数据抽成泛型，可以节省大量代码的编写
 *
 * Created by congxiaoyao on 2016/7/7.
 */
public class PagedBeanList<T extends ResponseBean> {

    private Page page;
    private List<T> rows;

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public List<T> getRows() {
        return rows;
    }

    public void setRows(List<T> rows) {
        this.rows = rows;
    }

    @Override
    public String toString() {
        return "PagedBeanList{" +
                "page=" + page +
                ", rows=" + rows +
                '}';
    }
}
