package com.congxiaoyao.segmenterror.response.beans;

/**
 * Created by congxiaoyao on 2016/7/9.
 */
public class User implements ResponseBean {

    private String name;
    private String slug;
    private Long id;
    private String url;         //个人信息页
    private String avatarUrl;   //头像地址
    private String cityName;
    private String rank;        //声望值
    private int likedVotes;     //被赞赏
    private int badges;         //徽章数
    private int questions;      //提问数
    private int answers;        //回答数
    private int articles;       //数文章
    private int gender;         //1为男2为女
    private String description; //自我介绍
    private String birthday;    //生日
    private boolean isFollowed; //是否已经关注了

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public int getLikedVotes() {
        return likedVotes;
    }

    public void setLikedVotes(int likedVotes) {
        this.likedVotes = likedVotes;
    }

    public int getBadges() {
        return badges;
    }

    public void setBadges(int badges) {
        this.badges = badges;
    }

    public int getQuestions() {
        return questions;
    }

    public void setQuestions(int questions) {
        this.questions = questions;
    }

    public int getAnswers() {
        return answers;
    }

    public void setAnswers(int answers) {
        this.answers = answers;
    }

    public int getArticles() {
        return articles;
    }

    public void setArticles(int articles) {
        this.articles = articles;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public boolean isFollowed() {
        return isFollowed;
    }

    public void setFollowed(boolean followed) {
        isFollowed = followed;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", slug='" + slug + '\'' +
                ", id=" + id +
                ", url='" + url + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                ", cityName='" + cityName + '\'' +
                ", rank='" + rank + '\'' +
                ", likedVotes=" + likedVotes +
                ", badges=" + badges +
                ", questions=" + questions +
                ", answers=" + answers +
                ", articles=" + articles +
                ", gender=" + gender +
                ", description='" + description + '\'' +
                ", birthday='" + birthday + '\'' +
                ", isFollowed=" + isFollowed +
                '}';
    }
}
