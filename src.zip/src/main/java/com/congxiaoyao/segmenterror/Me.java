package com.congxiaoyao.segmenterror;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;

import com.congxiaoyao.segmenterror.response.beans.SimpleUser;
import com.congxiaoyao.segmenterror.response.beans.User;

/**
 * 关于我的信息的SharedPreference操作 可以从中读取或向其写入数据
 * 这里也是token的唯一获取类，通过静态方法token获取
 *
 * 其中SharedPreference中查不到的字段是以null为查询结果的 使用时请做好空指针检测
 *
 * Created by congxiaoyao on 2016/8/21.
 */
public class Me {

    private static final String FILE_NAME = "SE_USER_STORE.xml";

    private String slug;
    private String id;
    private String token;
    private String rank;
    private String url;
    private String name;
    private String email;
    private String avatarUrl;

    private static String TOKEN = null;

    private Me() {

    }

    /**
     * 读取SharedPreference并生成me对象
     * @param context
     * @return
     */
    public static Me fromSharedPreferences(Context context) {
        Me me = new Me();
        SharedPreferences sharedPreferences = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);
        me.slug = sharedPreferences.getString("slug", null);
        me.id = sharedPreferences.getString("id", null);
        me.token = sharedPreferences.getString("token", null);
        me.rank = sharedPreferences.getString("rank", null);
        me.url = sharedPreferences.getString("url", null);
        me.name = sharedPreferences.getString("name", null);
        me.email = sharedPreferences.getString("email", null);
        me.avatarUrl = sharedPreferences.getString("avatarUrl", null);
        return me;
    }

    /**
     * 获取token
     * @param context
     * @return
     */
    public static String token(Context context) {
        if (TOKEN != null) return TOKEN;
        SharedPreferences sharedPreferences = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);
        return TOKEN = sharedPreferences.getString("token", null);
    }

    /**
     * 保存用户信息
     * @param context
     * @param user
     */
    public static void save(Context context, SimpleUser user) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        save(editor, "slug", user.getSlug());
        save(editor, "id", user.getId() + "");
        save(editor, "rank", user.getRank());
        save(editor, "url", user.getUrl());
        save(editor, "name", user.getName());
        save(editor, "mail", user.getMail());
        save(editor, "avatarUrl", user.getAvatarUrl());
        editor.commit();
    }

    /**
     * 保存token
     *
     * @param context
     * @param token
     */
    public static void saveToken(Context context, String token) {
        Me.TOKEN = token;
        SharedPreferences sharedPreferences = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("token", token);
        editor.commit();
    }

    /**
     * 如果value是空的，则删掉原来的数据 这样再次查询的时候才会查出来是null
     * @param editor
     * @param key
     * @param value
     */
    private static void save(SharedPreferences.Editor editor, @NonNull String key, String value) {
        if (value == null) {
            editor.remove(key);
        }else {
            editor.putString(key, value);
        }
    }

    /**
     * 清空sharedpreference中的数据
     * @param context
     */
    public static void clear(Context context) {
        Me.TOKEN = null;
        SharedPreferences sharedPreferences = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }

    /**
     * 清空sharedpreference中的数据 但是不清除email
     * @param context
     */
    public static void clearWithoutEmail(Context context) {
        Me.TOKEN = null;
        SharedPreferences sharedPreferences = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);
        String email = sharedPreferences.getString("email", null);
        clear(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (email != null) {
            editor.putString("email", email);
            editor.commit();
        }
    }

    public String getSlug() {
        return slug;
    }

    public String getId() {
        return id;
    }

    public String getToken() {
        return token;
    }

    public String getRank() {
        return rank;
    }

    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    @Override
    public String toString() {
        return "Me{" +
                "slug='" + slug + '\'' +
                ", id='" + id + '\'' +
                ", token='" + token + '\'' +
                ", rank='" + rank + '\'' +
                ", url='" + url + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                '}';
    }
}