package com.congxiaoyao.segmenterror;

import android.support.v4.widget.ContentLoadingProgressBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.request.UserRequest;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.exception.ExceptionDispatcher;
import com.congxiaoyao.segmenterror.response.exception.ResponseException;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.response.exception.ToastAndLogExceptionHandler;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.subscriptions.CompositeSubscription;

public class LoginActivity extends AppCompatActivity {

    public static final int CODE_RESULT_SUCCESS = 200;
    public static final int CODE_RESULT_FAILED = 400;

    private EditText emailET;
    private EditText passwordET;

    private ExceptionDispatcher dispatcher;
    private ContentLoadingProgressBar progressBar;

    private CompositeSubscription subscriptions;

    private boolean isLogining = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("登录");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        emailET = (EditText) findViewById(R.id.et_email);
        passwordET = (EditText) findViewById(R.id.et_password);
        Button button = (Button) findViewById(R.id.btn_login);
        button.setOnClickListener(v -> {
            if(isLogining) return;
            isLogining = true;
            doLogin();
        });

        Me me = Me.fromSharedPreferences(this);
        if (me.getEmail() != null) {
            emailET.setText(me.getEmail());
        }

        subscriptions = new CompositeSubscription();
        dispatcher = new ExceptionDispatcher();
        dispatcher.setExceptionHandler(new ToastAndLogExceptionHandler(() -> this));
    }

    private void doLogin() {
        Log.d(com.congxiaoyao.segmenterror.utils.TAG.ME, "doLogin: ");
        String email = emailET.getText().toString();
        if (email == null || email.equals("")) {
            Toast.makeText(LoginActivity.this, "email 不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        String password = passwordET.getText().toString();
        if (email == null || email.equals("")) {
            Toast.makeText(LoginActivity.this, "password 不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar = (ContentLoadingProgressBar)
                findViewById(R.id.content_loading_progress);
        progressBar.show();
        Subscription subscribe = SERetrofit.create(UserRequest.class)
                .login(email, password)
                .compose(ResponsePreProcess::dataToBean)
                .doOnNext(loginInfo -> {
                    Me.save(this, loginInfo.getUser());
                    Me.saveToken(this, loginInfo.getToken());
                }).observeOn(AndroidSchedulers.mainThread())
                .subscribe(loginInfo -> {
                    progressBar.hide();
                    setResult(CODE_RESULT_SUCCESS);
                    finish();
                }, dispatcher::dispatchException);
        subscriptions.add(subscribe);
    }

    @Override
    public boolean onSupportNavigateUp() {
        super.onBackPressed();
        return true;
    }

    @Override
    protected void onDestroy() {
        subscriptions.unsubscribe();
        super.onDestroy();

    }

    class LoginExceptionHandler extends ToastAndLogExceptionHandler {

        public LoginExceptionHandler(ToastAndLogExceptionHandler.ContextProvider context) {
            super(context);
        }

        @Override
        public void onDispatchException(Throwable throwable) {
            isLogining = false;
            progressBar.hide();
        }

        @Override
        public boolean onLoginError(String reason) {
            Toast.makeText(LoginActivity.this, reason, Toast.LENGTH_SHORT).show();
            return true;
        }

        @Override
        public void onResponseError(ResponseException exception) {
            Toast.makeText(LoginActivity.this, "登录错误", Toast.LENGTH_SHORT).show();
        }
    }

}