package com.congxiaoyao.segmenterror.articlelist;

import android.widget.ImageView;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.mvpbase.presenter.ListLoadablePresenterImpl;
import com.congxiaoyao.segmenterror.request.ArticleRequest;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.response.beans.Article;
import com.congxiaoyao.segmenterror.utils.DisplayUtils;
import com.squareup.picasso.Picasso;

import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by congxiaoyao on 2016/9/3.
 */
public class ArticlePresenter
        extends ListLoadablePresenterImpl<ArticleListFragment>
        implements IArticlePresenter{

    private static final int TYPE_RECOMMENDED = 0;  //推荐的
    private static final int TYPE_NEWEST = 1;       //全部的
    private static final int TYPE_HOTTEST = 2;      //热门的

    private int currentType = 0;

    private boolean isLoading = false;

    private final Object avatarTag = new Object();

    public ArticlePresenter(ArticleListFragment view) {
        super(view);
    }

    @Override
    public Observable<ResponsePagedListData<Article>> pullPagedListData(int page) {
        return createRequestByType(page);
    }

    @Override
    public void changeToRecommended() {
        if (currentType == TYPE_RECOMMENDED) return;
        currentType = TYPE_RECOMMENDED;
        subscribeByCurrentType();
    }

    @Override
    public void changeToHottest() {
        if (currentType == TYPE_HOTTEST) return;
        currentType = TYPE_HOTTEST;
        subscribeByCurrentType();
    }

    @Override
    public void changeToNewest() {
        if (currentType == TYPE_NEWEST) return;
        currentType = TYPE_NEWEST;
        subscribeByCurrentType();
    }

    private void subscribeByCurrentType() {
        if (isLoading) return;
        view.showLoading();
        Subscription subscription = createRequestByType(1)
                .compose(ResponsePreProcess.pagedListDataToBeanList(this::savePage))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(list -> {
                    view.showNothing();
                    view.addData(list);
                    view.hideLoading();
                    isLoading = false;
                }, exceptionDispatcher::dispatchException);
        subscriptions.add(subscription);
        isLoading = true;
    }

    /**
     * 根据当前的类型请求数据 返回observable对象，只是单纯的observable，并不包括后续处理
     * @param requestPage
     * @return
     */
    private Observable<ResponsePagedListData<Article>> createRequestByType(int requestPage) {
        ArticleRequest request = SERetrofit.create(ArticleRequest.class);
        Observable<ResponsePagedListData<Article>> observable = null;
        //当前的种类正常下有三种 TYPE_NEWEST TYPE_HOTTEST TYPE_UNANSWERED
        //根据不同的种类返回不同的Observable
        switch (currentType) {
            case TYPE_RECOMMENDED:
                observable = request.getRecommendArticles(requestPage);
                break;
            case TYPE_NEWEST:
                observable = request.getNewestArticles(requestPage);
                break;
            case TYPE_HOTTEST:
                observable = request.getHottestArticles(requestPage);
                break;
            default:
                throw new RuntimeException("current state error");
        }
        return observable;
    }

    @Override
    public void jumpToArticle(Long id) {
        Toast.makeText(view.getContext(), "article id = " + id, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void loadImage(String url, ImageView imageView) {
        int size = DisplayUtils.dp2px(view.getContext(), 40);
        Picasso.with(view.getContext())
                .load(url)
                .resize(size, size)
                .placeholder(R.drawable.ic_avatar)
                .error(R.drawable.ic_avatar)
                .tag("avatarTag")
                .into(imageView);
    }

    @Override
    public void unSubscribe() {
        super.unSubscribe();
        Picasso.with(view.getContext()).cancelTag(avatarTag);
    }

    @Override
    public void onDispatchException(Throwable throwable) {
        super.onDispatchException(throwable);
    }
}