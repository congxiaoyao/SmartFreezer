package com.congxiaoyao.segmenterror.articlelist;

import android.widget.ImageView;

import com.congxiaoyao.segmenterror.mvpbase.presenter.ListLoadablePresenter;

/**
 * Created by congxiaoyao on 2016/9/3.
 */
public interface IArticlePresenter extends ListLoadablePresenter {

    void changeToRecommended();

    void changeToHottest();

    /**
     * 全部的
     */
    void changeToNewest();

    void jumpToArticle(Long id);

    void loadImage(String url, ImageView imageView);
}
