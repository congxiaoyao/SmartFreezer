package com.congxiaoyao.segmenterror.articlelist;


import android.view.View;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseViewHolder;
import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.mvpbase.view.SimpleListLoadableView;
import com.congxiaoyao.segmenterror.response.beans.Article;
import com.squareup.picasso.Picasso;

public class ArticleListFragment extends SimpleListLoadableView<IArticlePresenter,Article> {

    @Override
    protected int getPageSize() {
        return 30;
    }

    @Override
    protected void convert(BaseViewHolder viewHolder, Article data) {
        ImageView avatar = viewHolder.getView(R.id.iv_avatar);
        viewHolder.setText(R.id.tv_title, data.getTitle())
                .setText(R.id.tv_outline, data.getExcerpt())
                .setText(R.id.tv_vote, data.getVotes() + "")
                .setText(R.id.tv_time, data.getCreatedDate())
                .setText(R.id.tv_comment, data.getComments() + "评论");
        presenter.loadImage(data.getUser().getAvatarUrl(), avatar);
    }

    @Override
    protected int getItemLayoutResId() {
        return R.layout.item_article_outline;
    }

    @Override
    protected void onItemClicked(Article article, View view) {
        presenter.jumpToArticle(article.getId());
    }
}
