package com.congxiaoyao.segmenterror.utils;

import rx.functions.Action1;
import rx.functions.Func0;

/**
 * Created by congxiaoyao on 2016/8/14.
 */
public class HookUtil {

    /**
     * 此函数允许在返回一个T类型的对象之前插入一些代码
     * @param func0
     * @param <T>
     * @return
     */
    public static <T> T hook(Func0<T> func0) {
        return func0.call();
    }

    /**
     * 此函数允许对一个T类型的对象做操作后仍返回他自己
     *
     * @param action1
     * @param <T>
     * @return
     */
    public static <T> T hook(T t, Action1<T> action1) {
        action1.call(t);
        return t;
    }

}
