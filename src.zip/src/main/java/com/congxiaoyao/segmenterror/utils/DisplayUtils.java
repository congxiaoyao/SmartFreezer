package com.congxiaoyao.segmenterror.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by congxiaoyao on 2016/7/20.
 */
public class DisplayUtils {

    private static Rect frame = new Rect();
    private static Point point = new Point();

    /**
     * 获取系统标题栏高度
     * @param activity
     * @return
     */
    public static int getStatusBarHeight(Activity activity) {
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        return frame.top;
    }

    /**
     * 测量view宽高
     * @param view
     * @return
     */
    public static Point measureView(View view){
        view.measure(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        point.x = view.getMeasuredWidth();
        point.y = view.getMeasuredHeight();
        return point;
    }

    /**
     * px to dip 尺寸不变
     *
     * @param context
     * @param pxValue
     * @return
     */
    public static int px2dip(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    /**
     * dp to px
     *
     * @param context
     * @param dp
     * @return
     */
    public static int dp2px(Context context, int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp, context.getResources().getDisplayMetrics());
    }

}
