package com.congxiaoyao.segmenterror.utils;

import rx.Observable;
import rx.Subscriber;

/**
 * Created by congxiaoyao on 2016/8/24.
 */
public class RxJavaUtils {

    /**
     * 类似于Observable的buffer方法 这里虽然也是将数据分组，但效果不太相同
     * 如Observable的buffer方法将六个数据分为两组，三个一组则会回调两次
     * 而此方法六个数据分为两组，则至少会回调4次
     * 如果有数据 1 2 3 4 5 6
     * 在full变量为true的时候的回调为 123 234 345 456
     * 在full变量为false的时候的回调为 1 12 123 234 345 456
     *
     * @param count 几个一组
     * @param full 是否等满了再发射数据
     * @param <T>
     * @return
     */
    public static <T> Observable.Transformer<T, RoundList<T>> buffer(int count, boolean full) {
        RoundList<T> roundList = new RoundList<>(count);
        return new Observable.Transformer<T, RoundList<T>>() {
            @Override
            public Observable<RoundList<T>> call(Observable<T> tObservable) {
                return Observable.create(new Observable.OnSubscribe<RoundList<T>>() {
                    @Override
                    public void call(Subscriber<? super RoundList<T>> subscriber) {
                        tObservable.subscribe(t -> {
                            roundList.add(t);
                            if (full && roundList.size() != count) {
                                return;
                            }
                            subscriber.onNext(roundList);
                        });
                    }
                });
            }
        };
    }

}
