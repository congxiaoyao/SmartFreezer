package com.congxiaoyao.segmenterror.utils;

/**
 * Created by congxiaoyao on 2016/8/24.
 */
public class TAG {
    public static final String ME = "cxy";
}
