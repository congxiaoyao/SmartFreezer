package com.congxiaoyao.segmenterror.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 反射工具类
 *
 * Created by congxiaoyao on 2016/7/25.
 */
public class ReflectUtil {

    /**
     * 反射一个对象中的私有变量
     * @param fieldName
     * @param object
     * @return
     */
    public static Object getField(String fieldName, Object object) {
        try {
            Field field = object.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(object);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Object getField(String fieldName, Object object, Class classOfObejct) {
        try {
            Field field = classOfObejct.getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(object);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void invokeMethod(String methodName, Object object,
                                      Class<?>[] parameterTypes, Object[] args) {
        try {
            Method method = object.getClass().getDeclaredMethod(methodName, parameterTypes);
            method.setAccessible(true);
            method.invoke(object, args);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void invokeMethod(String methodName, Object object, Class classOfObejct,
                                    Class<?>[] parameterTypes, Object[] args) {
        try {
            Method method = classOfObejct.getDeclaredMethod(methodName, parameterTypes);
            method.setAccessible(true);
            method.invoke(object, args);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

}
