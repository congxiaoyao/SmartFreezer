package com.congxiaoyao.segmenterror.utils;

import android.content.Context;
import android.content.Intent;

import com.congxiaoyao.segmenterror.questiondetail.QuestionDetailActivity;

/**
 * Created by congxiaoyao on 2016/9/10.
 */
public class ActivityUtils {

    public static void jumpToQuestion(Context context, Long id) {
        Intent intent = new Intent(context, QuestionDetailActivity.class);
        intent.putExtra(QuestionDetailActivity.QID, id);
        context.startActivity(intent);
    }
}
