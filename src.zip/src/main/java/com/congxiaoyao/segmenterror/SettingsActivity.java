package com.congxiaoyao.segmenterror;

import android.app.FragmentTransaction;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.utils.HookUtil;
import com.congxiaoyao.segmenterror.utils.RoundList;
import com.congxiaoyao.segmenterror.utils.RxJavaUtils;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("设置");

        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_content, new SettingsFragment());
        transaction.commit();
    }

    @Override
    public boolean onSupportNavigateUp() {
        super.onBackPressed();
        return true;
    }

    public static class SettingsFragment extends PreferenceFragment implements
            SharedPreferences.OnSharedPreferenceChangeListener {

        private static final String TAG = "cxy";

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.settings);

            Preference logout = findPreference("logout");
            logout.setOnPreferenceClickListener(preference -> {
                Me.clearWithoutEmail(getActivity());
                getActivity().finish();
                return true;
            });

            Preference version = findPreference("version");

            Observable.create(subscriber -> {
                version.setOnPreferenceClickListener(preference ->
                        HookUtil.hook(true, b -> subscriber.onNext(System.currentTimeMillis())));
            }).compose(RxJavaUtils.buffer(4, true)).subscribe(list->{
                long first = (long) list.getFirst();
                long last = (long) list.getLast();
                if (last - first < 800) {
                    list.removeAll();
                    Toast.makeText(getActivity(), "clicked "+(last-first), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public void onResume() {
            super.onResume();
            getPreferenceManager().getSharedPreferences()
                    .registerOnSharedPreferenceChangeListener(this);

        }

        @Override
        public void onPause() {
            getPreferenceManager().getSharedPreferences()
                    .unregisterOnSharedPreferenceChangeListener(this);
            super.onPause();
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        }
    }

}
