package com.congxiaoyao.segmenterror.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;

/**
 * Created by congxiaoyao on 2016/9/6.
 */
public class FullScreenFrameLayout extends FrameLayout{

    public FullScreenFrameLayout(Context context) {
        super(context);
    }

    public FullScreenFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FullScreenFrameLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        ViewParent viewParent = this;
        while ((viewParent = viewParent.getParent()) != null) {
            if (!(viewParent instanceof ViewGroup)) break;
            ViewGroup viewGroup = (ViewGroup) viewParent;
            if(viewGroup.getPaddingTop() != 0) {
                viewGroup.setPadding(viewGroup.getPaddingLeft(), 0, viewGroup.getPaddingRight(),
                        viewGroup.getPaddingBottom());
            }
        }
    }
}
