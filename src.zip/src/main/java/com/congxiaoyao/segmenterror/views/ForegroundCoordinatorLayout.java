package com.congxiaoyao.segmenterror.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.util.Log;

import com.congxiaoyao.segmenterror.R;

/**
 * Created by congxiaoyao on 2016/7/28.
 */
public class ForegroundCoordinatorLayout extends CoordinatorLayout {

    private Drawable drawable;
    private WindowInsetsCompat windowInsets;

    public ForegroundCoordinatorLayout(Context context) {
        super(context);
        init();
    }

    public ForegroundCoordinatorLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ForegroundCoordinatorLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        onDrawForeground(canvas);
    }

    private void init() {
        ViewCompat.setOnApplyWindowInsetsListener(this, (v, insets) -> {
            this.windowInsets = insets;
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            return insets;
        });
    }

    @Override
    public void onDrawForeground(Canvas canvas) {
        drawable = new ColorDrawable(ContextCompat.getColor(getContext(), R.color.colorStatusBar));
        if (windowInsets != null) {
            drawable.setBounds(0, 0, getWidth(), windowInsets.getSystemWindowInsetTop());
            drawable.draw(canvas);
        }
    }
}
