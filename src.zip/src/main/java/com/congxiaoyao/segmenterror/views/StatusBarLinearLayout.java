package com.congxiaoyao.segmenterror.views;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v7.widget.FitWindowsLinearLayout;
import android.util.AttributeSet;
import android.util.Log;

import com.congxiaoyao.segmenterror.R;

/**
 * Created by congxiaoyao on 2016/8/24.
 */
public class StatusBarLinearLayout extends FitWindowsLinearLayout{

    private static final String TAG = "cxy";
    private WindowInsetsCompat windowInsets;
    private Drawable drawable;

    public StatusBarLinearLayout(Context context) {
        super(context);
        init();
    }

    public StatusBarLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        Log.d(TAG, "init: ");
        ViewCompat.setOnApplyWindowInsetsListener(this, (v, insets) -> {
            this.windowInsets = insets;
            Log.d(TAG, "init: window insets");
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            return insets;
        });
    }

    @Override
    public void draw(Canvas canvas) {
        Log.d(TAG, "draw: ");
        super.draw(canvas);
        drawStatusBar(canvas);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Log.d(TAG, "onDraw: ");
        super.onDraw(canvas);
    }

    private void drawStatusBar(Canvas canvas) {
        drawable = new ColorDrawable(ContextCompat.getColor(getContext(), R.color.colorStatusBar));
        if (windowInsets != null) {
            drawable.setBounds(0, -60, getWidth(),0);
            Log.d(TAG, "drawStatusBar: " + String.format("%d,%d,%d,%d", 0, 0, getWidth(), windowInsets.getSystemWindowInsetTop()));
            drawable.draw(canvas);
        }
    }
}
