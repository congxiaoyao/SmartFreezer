package com.congxiaoyao.segmenterror.views;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.response.beans.Notification;
import com.congxiaoyao.segmenterror.response.beans.SimpleUser;
import com.congxiaoyao.segmenterror.utils.HookUtil;

import java.util.List;

import rx.functions.Action1;

/**
 * 此类专门用于显示一个Notification对象所包含的信息
 * 由于不同的Notification类型不同，所以显示的规则也会多种多样，我们把类内可以点击的文字作为span来管理
 * 向外界暴露了{@link NotificationTextView#onSpanClick(Action1)}方法用于监听某些span的点击事件
 * 使用者只需要通过{@link NotificationTextView#setNotification(Notification)}方法传入数据即可自动完成展示
 *
 * 在点击回调中，有两种span是会被传入回调函数的 分别为{@link UserSpan} {@link QuestionTitleSpan}
 * 可以在回调中判断参数的具体类型从而完成跳转操作
 *
 * Created by congxiaoyao on 2016/8/15.
 */
public class NotificationTextView extends TextView {

    private static final String TAG = "cxy";

    private static final String BASE_URL = "https://www.segmentfault.com/";

    private Notification notification;
    private Action1<MyClickableSpan> onSpanClick;

    public NotificationTextView(Context context) {
        super(context);
    }

    public NotificationTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public NotificationTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setNotification(Notification notification) {
        this.notification = notification;
        switch (notification.getObject().getType()) {
            case "question":
                handleQuestionNotification(notification);
                break;
            case "badge":
                handleBadgeNotification(notification);
                break;
            case "user":
                handleUserNotification(notification);
                break;
            default:
                setText(notification.getTitle());
        }
    }

    public Notification getNotification() {
        return notification;
    }

    /**
     * 当这通知的type为question的时候的处理方式
     *
     * @param notification
     */
    private void handleQuestionNotification(Notification notification) {
        List<SimpleUser> users = notification.getTarget().getUsers();
        setText(Html.fromHtml(notification.getSentence()));
        setMovementMethod(LinkMovementMethod.getInstance());

        //这个对象的内容为 XXX回答了
        Spannable spannable = (Spannable) getText();
        //提取出其中的超链接
        URLSpan[] urls = spannable.getSpans(0, spannable.length(), URLSpan.class);
        SpannableStringBuilder ssb = new SpannableStringBuilder(spannable);
        ssb.clearSpans();
        //将提取出的超链接转化为UserSpan并将其依次添加进ssb中
        for (int i = 0; i < urls.length; i++) {
            if (i >= users.size()) return;
            URLSpan urlSpan = urls[i];
            //一般来说URLSpan数组跟user集合元素以一一对应的
            UserSpan userSpan = new UserSpan(users.get(i));
            //重新生成新的span
            ssb.setSpan(userSpan, spannable.getSpanStart(urlSpan),
                    spannable.getSpanEnd(urlSpan), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        setText(ssb);

        //然后把回答的问题也变成可点击的并添加进去
        SpannableString title = new SpannableString(" " + notification.getTitle());
        title.setSpan(new QuestionTitleSpan(notification.getTitle(), notification.getObject().getId()),
                0, title.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        append(title);
    }

    /**
     * 当通知的type为badge时候的处理方式
     *
     * @param notification
     */
    public void handleBadgeNotification(Notification notification) {
        setText(notification.getSentence());

        SpannableString text = new SpannableString(" "+notification.getTitle());
        URLSpan urlSpan = new URLSpan(BASE_URL + "b/" + notification.getObject().getId()) {
            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setColor(getHrefColor());
            }
        };
        text.setSpan(urlSpan, 0, text.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        setMovementMethod(LinkMovementMethod.getInstance());

        append(text);
    }

    /**
     * 当通知的type为user时候的处理方式
     * @param notification
     */
    private void handleUserNotification(Notification notification) {
        String sentence = HookUtil.hook(() -> {
            String str = notification.getSentence();
            int index = str.indexOf("<");
            return str.substring(0, index);
        });
        setText(sentence);

        SpannableString spannableString = new SpannableString(" " + notification.getTitle());
        spannableString.setSpan(new URLSpan(notification.getUrl()){
            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setColor(getHrefColor());
            }
        }, 0, spannableString.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);

        setMovementMethod(LinkMovementMethod.getInstance());
        append(spannableString);
    }

    /**
     * 设置span的点击监听
     * @param onSpanClick
     */
    public void onSpanClick(Action1<MyClickableSpan> onSpanClick) {
        this.onSpanClick = onSpanClick;
    }

    private int getHrefColor() {
        int color = ContextCompat.getColor(getContext(), R.color.colorPrimaryDark);
        return color;
    }

    /**
     * 给span内文字指定默认颜色为 colorPrimary
     */
    public class MyClickableSpan extends ClickableSpan {
        @Override
        public void updateDrawState(TextPaint ds) {
            ds.setColor(getHrefColor());
        }

        @Override
        public void onClick(View widget) {
            if (onSpanClick != null) {
                onSpanClick.call(this);
            }
        }
    }

    /**
     * 代表着问题标题的span
     */
    public class QuestionTitleSpan extends MyClickableSpan {
        private String title;
        private String qId;

        QuestionTitleSpan(String title, String qId) {
            this.title = title;
            this.qId = qId;
        }

        public String getTitle() {
            return title;
        }

        public String getqId() {
            return qId;
        }

        @Override
        public String toString() {
            return "QuestionTitleSpan -->" + title;
        }
    }

    /**
     * 代表着一个用户名的可点击区域
     */
    public class UserSpan extends MyClickableSpan {
        private SimpleUser simpleUser;

        UserSpan(SimpleUser simpleUser) {
            this.simpleUser = simpleUser;
        }

        public SimpleUser getSimpleUser() {
            return simpleUser;
        }

        @Override
        public String toString() {
            return "UserSpan-->" + simpleUser;
        }
    }
}
