package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.PagedBeanList;
import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;

import java.lang.reflect.Type;

/**
 * 详细注释见{@link ResponseData}
 *
 * Created by congxiaoyao on 2016/7/15.
 */
public class ResponsePagedListDataDeserializer extends
        BaseResponseDataDeserializer<ResponsePagedListData<?>,PagedBeanList<?>>{

    @Override
    protected ResponsePagedListData<?> getEmptyResponseData() {
        return new ResponsePagedListData<>();
    }

    @Override
    protected PagedBeanList<?> defaultDeserializeData(JsonObject responseData,
                                                      Type typeOfResponseData,
                                                      JsonDeserializationContext context) {
        return DeserializeHelper.getPagedListData(responseData.get("data"),
                context, typeOfResponseData);
    }
}
