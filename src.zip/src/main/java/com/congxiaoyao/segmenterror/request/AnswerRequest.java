package com.congxiaoyao.segmenterror.request;

import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.beans.Answer;

import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import rx.Observable;

/**
 * 包含的操作有:
 * <ul>
 * <li>获取某个问题的所有的回答</li>
 * </ul>
 * <p>
 * Created by congxiaoyao on 2016/7/10.
 */
public interface AnswerRequest {

    /**
     * 获取某个问题的所有的回答
     *
     * @param qid
     * @param token
     * @return
     */
    @GET("/question/{id}/answers")
    Observable<ResponseListData<Answer>> getAnswers(@Path("id") Long qid,
                                                    @Query("token") String token);

}