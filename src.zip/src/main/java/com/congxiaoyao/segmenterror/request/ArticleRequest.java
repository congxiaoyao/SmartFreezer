package com.congxiaoyao.segmenterror.request;

import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.beans.Article;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import rx.Observable;

/**
 * 包含的操作有:
 * <ul>
 * <li>获取文章详情</li>
 * <li>获取热门的文章列表</li>
 * <li>获取最新文章列表(全部的)</li>
 * <li>获取推荐的文章列表</li>
 * <li>获取某个分类的文章列表</li>
 * <li>获取某个用户的文章列表(我的文章)</li>
 * </ul>
 * Created by congxiaoyao on 2016/7/17.
 */
public interface ArticleRequest {

    /**
     * 获取文章详情
     * @param id 文章id
     * @param token
     * @return
     */
    @GET("article/{id}")
    Observable<ResponseData<Article>> detail(@Path("id") Long id,
                                             @Query("token") String token);

    /**
     * 获取热门的文章列表
     * @param page
     * @return
     */
    @GET("article/hottest")
    Observable<ResponsePagedListData<Article>> getHottestArticles(@Query("page") int page);

    /**
     * 获取最新文章列表(全部的)
     * @param page
     * @return
     */
    @GET("article/newest")
    Observable<ResponsePagedListData<Article>> getNewestArticles(@Query("page") int page);

    /**
     * 获取推荐的文章列表
     * @param page
     * @return
     */
    @GET("article/recommendable")
    Observable<ResponsePagedListData<Article>> getRecommendArticles(@Query("page") int page);

    /**
     * 获取某个分类的文章列表
     * @param tagId
     * @param page
     * @return
     */
    @GET("article/tagged/{tagId}")
    Observable<ResponsePagedListData<Article>> getTaggedArticles(@Path("tagId") Long tagId,
                                                                 @Query("page") int page);

    /**
     * 获取某个用户的文章列表(我的文章)
     * @param uid
     * @param page
     * @param token
     * @return
     */
    @GET("user/{uid}/articles")
    Observable<ResponsePagedListData<Article>> getUserArticles(@Path("uid") Long uid,
                                                               @Query("page") int page,
                                                               @Query("token") String token);
}
