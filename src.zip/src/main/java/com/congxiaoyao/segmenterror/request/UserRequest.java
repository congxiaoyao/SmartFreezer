package com.congxiaoyao.segmenterror.request;

import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.beans.LoginInfo;
import com.congxiaoyao.segmenterror.response.beans.Notification;
import com.congxiaoyao.segmenterror.response.beans.User;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.http.*;
import rx.Observable;

/**
 * 包含的操作有:
 * <ul>
 *     <li>个人信息查询</li>
 *     <li>登陆操作</li>
 *     <li>通过id查询id所代表的用户的信息</li>
 *     <li>通过slug查询slug所代表的用户的信息</li>
 * </ul>
 *
 * Created by congxiaoyao on 2016/7/9.
 */
public interface UserRequest {

    /**
     * 个人信息查询
     * @param token
     * @return
     */
    @GET("user/me")
    Observable<ResponseData<User>> me(@Query("token") String token);

    /**
     * 登陆操作
     * @param mail
     * @param password
     * @return {@link LoginInfo}
     */
    @FormUrlEncoded
    @POST("user/login")
    Observable<ResponseData<LoginInfo>> login(@Field("mail") String mail,
                                              @Field("password") String password);

    /**
     * 通过id查询id所代表的用户的信息
     * @param id
     * @param token
     * @return
     */
    @GET("user/{id}")
    Observable<ResponseData<User>> getInfoById(@Path("id") Long id,
                                               @Query("token") String token);

    /**
     * 通过slug查询slug所代表的用户的信息
     * @param slug
     * @param token
     * @return
     */
    @GET("u/{slug}")
    Observable<ResponseData<User>> getInfoBySlug(@Path("slug") String slug,
                                                 @Query("token") String token);

    /**
     * 我的消息记录
     * @param token
     * @param page
     * @param type
     * @return
     */
    @GET("user/events")
    Observable<ResponsePagedListData<Notification>> events(@Query("token") String token,
                                                           @Query("page") int page,
                                                           @Query("type") String type);
}
