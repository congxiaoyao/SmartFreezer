package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.PagedBeanList;
import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.beans.ResponseBean;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

/**
 * Created by congxiaoyao on 2016/7/15.
 */
public class DeserializeHelper {

    /**
     * 判断json数据的状态码，如果为1(也就是错误情况)将返回{@link ErrorInfo}
     * 否则将返回null
     *
     * @param responseData 代表整个返回的json信息的JsonObject
     * @param context
     * @return
     */
//    public static ErrorInfo tryToDecodeErrorInfo(JsonObject responseData,
//                                                 JsonDeserializationContext context) {
//        int status = responseData.get("status").getAsInt();
//        if (status != 1) return null;
//        JsonElement errorElement = responseData.get("mobile");
//        return context.deserialize(errorElement, ErrorInfo.class);
//    }

    /**
     * 解析json对象中的message字段
     * @param responseData 代表整个返回的json信息的JsonObject
     * @return
     */
    public static String getMessage(JsonObject responseData) {
        return responseData.get("message").getAsString();
    }

    /**
     * 解析json对象中的data字段,此方法只适用于{@link ResponseData}中的 data
     * @param dataElement 代表NormalData(一个bean)的JsonElement
     * @param context
     * @param type
     * @return
     */
    public static ResponseBean getNormalData(JsonElement dataElement,
                                             JsonDeserializationContext context,
                                             Type type) {
        ResponseBean data = context.deserialize(dataElement,
                ((ParameterizedType)type).getActualTypeArguments()[0]);
        return data;
    }

    /**
     * 解析json对象中的data字段,此方法只适用于{@link ResponseListData}中的 data
     * @param dataElement 代表ListData(泛型为一个bean的List)的JsonElement
     * @param context
     * @return
     */
    public static List<?> getListData(JsonElement dataElement,
                                      JsonDeserializationContext context,
                                      Type type) {
        Type beanType = ((ParameterizedType) type).getActualTypeArguments()[0];
        List data = context.deserialize(dataElement,
                getGenericFilledType(List.class, beanType));
        return data;
    }

    /**
     * 解析json对象中的data字段,此方法只适用于{@link ResponsePagedListData}中的 data
     * @param dataElement 代表PagedListData(泛型为一个bean的PagedBeanList)的JsonElement
     * @param context
     * @return
     */
    public static PagedBeanList<?> getPagedListData(JsonElement dataElement,
                                                    JsonDeserializationContext context,
                                                    Type type) {
        Type beanType = ((ParameterizedType) type).getActualTypeArguments()[0];
        PagedBeanList data = context.deserialize(dataElement,
                getGenericFilledType(PagedBeanList.class, beanType));
        return data;
    }

    /**
     * 获得一个被泛型填充的type 不能是内部类
     * @param classType 没有被泛型填充的type 如List、ResponseData等
     * @param genericType 泛型类型
     * @return
     */
    public static Type getGenericFilledType(Type classType, Type genericType) {
        return new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                return new Type[]{genericType};
            }

            @Override
            public Type getRawType() {
                return classType;
            }

            @Override
            public Type getOwnerType() {
                return null;
            }
        };
    }

    public static Type getGenericType(Type classType) {
        return ((ParameterizedType) classType).getActualTypeArguments()[0];
    }
}
