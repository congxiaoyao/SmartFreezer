package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.google.gson.*;

import java.lang.reflect.Type;
import java.util.List;

/**
 * 详细注释见{@link ResponseData}
 *
 * Created by congxiaoyao on 2016/7/15.
 */
public class ResponseListDataDeserializer extends BaseResponseDataDeserializer<ResponseListData<?>,List<?>> {

    public ResponseListDataDeserializer() {
    }

    public ResponseListDataDeserializer(DataDeserializer<List<?>>... dataDeserializers) {
        super(dataDeserializers);
    }

    @Override
    protected ResponseListData<?> getEmptyResponseData() {
        return new ResponseListData<>();
    }

    @Override
    protected List<?> defaultDeserializeData(JsonObject responseData,
                                          Type typeOfResponseData,
                                          JsonDeserializationContext context) {
        return DeserializeHelper.getListData(responseData.get("data"),
                context, typeOfResponseData);
    }

}
