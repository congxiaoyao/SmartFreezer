package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.beans.Comment;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.lang.reflect.Type;
import java.util.List;

/**
 * 在获取回答评论时，希望接受的对象为{@link ResponseListData <Comment>}类型的
 * 但是返回的json数据的data字段是{"rows":[{},{}...],total:x} 并不是期望的[{},{}...]
 * 于是手动剔除total以完成解析
 *
 * Created by congxiaoyao on 2016/7/16.
 */
public class CommentsDeserializer implements DataDeserializer<List<?>> {

    /**
     * @param responseData 代表整个json数据的JsonElement
     * @param typeOfResponseData 是{@link ResponseListData<?>}类型 不要弄乱了
     * @param context 帮助解析的JsonDeserializationContext
     * @return
     */
    @Override
    public List<Comment> deserializeData(JsonObject responseData,
                                         Type typeOfResponseData,
                                         JsonDeserializationContext context) {
        //只处理ResponseListData<Comment>的解析
        if (DeserializeHelper.getGenericType(typeOfResponseData) != Comment.class) return null;
        JsonElement dataElement = responseData.get("data");
        //如果是一个array就不处理了，交由父类使用默认方法处理或其他类处理
        if (dataElement.isJsonArray()) return null;
        JsonObject data = dataElement.getAsJsonObject();
        JsonElement jsonElement = data.get("rows");
        return context.deserialize(jsonElement,
                DeserializeHelper.getGenericFilledType(List.class, Comment.class));
    }
}
