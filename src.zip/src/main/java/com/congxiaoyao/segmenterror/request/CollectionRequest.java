package com.congxiaoyao.segmenterror.request;

import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.beans.Archive;
import com.congxiaoyao.segmenterror.response.beans.BookMark;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import rx.Observable;

/**
 * 包含的操作有:
 * <ul>
 * <li>获取一个收藏夹中收藏的内容的列表</li>
 * <li>获取我的收藏夹列表</li>
 * </ul>
 * Created by congxiaoyao on 2016/7/17.
 */
public interface CollectionRequest {

    /**
     * 获取一个收藏夹中收藏的内容的列表
     * @param id
     * @param token
     * @param page
     * @return
     */
    @GET("bookmarkArchive/{id}")
    Observable<ResponsePagedListData<BookMark>> getBookmarksByArchiveId(@Path("id") Long id,
                                                                        @Query("token") String token,
                                                                        @Query("page") int page);

    /**
     * 获取我的收藏夹列表
     * @param token
     * @param page
     * @return
     */
    @GET("/user/bookmarkArchives")
    Observable<ResponsePagedListData<Archive>> getArchives(@Query("token") String token,
//                                                    @Query("objectId") Long l,
                                                           @Query("page") int page);

}
