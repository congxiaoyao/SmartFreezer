package com.congxiaoyao.segmenterror.request;

import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.beans.Tag;
import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

/**
 * 所有关于tag的操作都在这里
 *
 * Created by congxiaoyao on 2016/7/7.
 */
public interface TagRequest {

    /**
     * 获取所有我关注的标签
     * @param token
     * @return
     */
    @GET("tag/following")
    Observable<ResponseListData<Tag>> myTags(@Query("token") String token);
}
