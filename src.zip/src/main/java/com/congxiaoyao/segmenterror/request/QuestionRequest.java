package com.congxiaoyao.segmenterror.request;

import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.beans.AnsweredQuestion;
import com.congxiaoyao.segmenterror.response.beans.InvitedQuestion;
import com.congxiaoyao.segmenterror.response.beans.Question;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import rx.Observable;

/**
 * 包含的操作有:
 * <ul>
 * <li>问题详情查询</li>
 * <li>我关注的问题查询</li>
 * <li>最热问题查询</li>
 * <li>最新问题查询</li>
 * <li>属于某个标签下的问题查询</li>
 * <li>未回答的问题查询</li>
 * <li>某个用户的的提问查询</li>
 * <li>某个用户回答过的问题查询(我的回答)</li>
 * <li>邀请我回答的问题列表(邀请我回答的)</li>
 * </ul>
 * <p>
 * Created by congxiaoyao on 2016/7/10.
 */
public interface QuestionRequest {

    /**
     * 问题详情查询
     *
     * @param id
     * @param token
     * @return
     */
    @GET("question/{id}")
    Observable<ResponseData<Question>> detail(@Path("id") Long id,
                                              @Query("token") String token);

    /**
     * 我关注的问题查询
     *
     * @param page
     * @param token
     * @return
     */
    @GET("question/following")
    Observable<ResponsePagedListData<Question>> getFollowingQuestions(@Query("page") int page,
                                                                      @Query("token") String token);

    /**
     * 最热问题查询
     *
     * @param page
     * @param token
     * @return
     */
    @GET("question/hottest")
    Observable<ResponsePagedListData<Question>> getHottestQuestions(@Query("page") int page,
                                                                    @Query("token") String token);

    /**
     * 最新问题查询
     *
     * @param page
     * @param token
     * @return
     */
    @GET("question/newest")
    Observable<ResponsePagedListData<Question>> getNewestQuestions(@Query("page") int page,
                                                                   @Query("token") String token);

    /**
     * 属于某个标签下的问题查询
     *
     * @param tag
     * @param page
     * @param token
     * @return
     */
    @GET("question/tagged/{tag}")
    Observable<ResponsePagedListData<Question>> getTaggedQuestions(@Path("tag") Long tag,
                                                                   @Query("page") int page,
                                                                   @Query("token") String token);

    /**
     * 未回答的问题查询
     *
     * @param page
     * @param token
     * @return
     */
    @GET("question/unanswered")
    Observable<ResponsePagedListData<Question>> getUnAnsweredQuestions(@Query("page") int page,
                                                                       @Query("token") String token);

    /**
     * 某个用户的的提问查询
     *
     * @param id
     * @param page
     * @param token
     * @return
     */
    @GET("user/{id}/questions")
    Observable<ResponsePagedListData<Question>> getUserQuestions(@Path("id") Long id,
                                                                 @Query("page") int page,
                                                                 @Query("token") String token);

    /**
     * 用户回答过的问题查询
     * @param uid
     * @param token
     * @param page
     * @return
     */
    @GET("user/{id}/answers")
    Observable<ResponsePagedListData<AnsweredQuestion>> getAnsweredQuestions(@Path("id") Long uid,
                                                                             @Query("token") String token,
                                                                             @Query("page") int page);

    /**
     * 邀请我回答的问题列表
     * @param page
     * @param token
     * @return
     */
    @GET("/question/invited")
    Observable<ResponsePagedListData<InvitedQuestion>> getInvitedQuestions(@Query("page") int page,
                                                                           @Query("token") String token);


}
