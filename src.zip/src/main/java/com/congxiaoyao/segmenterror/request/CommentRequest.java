package com.congxiaoyao.segmenterror.request;

import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.beans.Comment;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import rx.Observable;

/**
 * 包含的操作有:
 * <ul>
 * <li>获取某个回答的评论</li>
 * <li>获取某个文章的评论</li>
 * <li>获取某个问题的评论</li>
 * </ul>
 * <p>
 *
 * Created by congxiaoyao on 2016/7/16.
 */
public interface CommentRequest {

    /**
     * 获取某个回答的评论
     * @param id 回答的id
     * @param token
     * @return
     */
    @GET("answer/{id}/comments")
    Observable<ResponseListData<Comment>> getAnswerComments(@Path("id") Long id,
                                                            @Query("token") String token);

    /**
     * 获取某个文章的评论
     * @param id 文章的id
     * @param token
     * @return
     */
    @GET("article/{id}/comments")
    Observable<ResponseListData<Comment>> getArticleComments(@Path("id") Long id,
                                                             @Query("token") String token);

    /**
     * 获取某个问题的评论
     * @param id 问题的id
     * @param token
     * @return
     */
    @GET("question/{id}/comments")
    Observable<ResponseListData<Comment>> getQuestionComments(@Path("id") Long id,
                                                              @Query("token") String token);
}
