package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Created by congxiaoyao on 2016/3/29.
 */
public class GsonHelper {

    private static Gson gson = null;

    static {
        gson = new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(ResponseData.class,
                        new ResponseDataDeserializer())
                .registerTypeAdapter(ResponseListData.class,
                        new ResponseListDataDeserializer(new CommentsDeserializer()))
                .registerTypeAdapter(ResponsePagedListData.class,
                        new ResponsePagedListDataDeserializer())
                .create();
    }

    public static Gson getInstance() {
        return gson;
    }

}
