package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.beans.ResponseBean;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;

import java.lang.reflect.Type;

/**
 * 此类干预了json数据到ResponseData的解析过程，加入了当状态码为1时产生的错误信息的处理
 * 由于{@link JsonDeserializer}不支持继承，所以必须为{@link ResponseData}、{@link ResponseListData}、
 * {@link ResponsePagedListData} 他们三个每人都写一个反序列化操作类,实现相同的功能
 * 同时由于继承了{@link BaseResponseDataDeserializer} 此类允许定义data的解析操作
 * 不知道服务器程序员怎么想的，随便乱改json结构，我这还得这么麻烦！！
 *
 * Created by congxiaoyao on 2016/7/16.
 */
public class ResponseDataDeserializer extends BaseResponseDataDeserializer<ResponseData<?>, ResponseBean> {


    public ResponseDataDeserializer() {
    }

    public ResponseDataDeserializer(DataDeserializer<ResponseBean>... dataDeserializers) {
        super(dataDeserializers);
    }

    @Override
    protected ResponseData<?> getEmptyResponseData() {
        return new ResponseData<>();
    }

    @Override
    protected ResponseBean defaultDeserializeData(JsonObject responseData,
                                                  Type typeOfResponseData,
                                                  JsonDeserializationContext context) {
        return DeserializeHelper.getNormalData(responseData.get("data"),
                context, typeOfResponseData);
    }

}
