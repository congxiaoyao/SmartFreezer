package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.google.gson.*;

import java.lang.reflect.Type;
import java.util.LinkedList;

/**
 * 为其子类提供自定义data解析功能，data是指json数据中的data字段
 * 如 某个回答的评论，假设我的data字段注册为解析成List类型的(我们希望将其解析为list型)，
 * 但实际上data字段为Object类型的因为其多了一个total字段 他们将list和total封装为一个Object
 * 所以按照Gson所提供的解析规则将无法顺利完成解析，需要人工干预
 *
 * 我们已经为三种json数据提供了默认的干预规则
 * 这三种json数据的实体类为 {@link ResponseListData}、
 * {@link ResponsePagedListData} 、{@link ResponseData} 分别由三个子类实现干预
 * 当出现错误请求时，默认的干预规则将应对json数据的格式发生变化的问题
 * 但是这还不够，在json数据正确的情况下，我们希望所有的json数据都能够解析为我们所期望的三种对象
 * 如开头所述的这种情况可能会有很多，所以应该允许提供自定义的对data字段的解析规则
 *
 * 这个类允许使用者在默认干预规则的前提下，添加自己的干预规则，也就是自己负责解析data字段
 * 具体方式为实现一个{@link DataDeserializer}并将其传入{@link BaseResponseDataDeserializer}中
 * 当使用者对某种数据的解析感兴趣时，他们将会自己实现解析过程并返回解析结果
 * 如果解析结果为空，则视为解析无效，继续使用默认(Gson提供)的方式对data字段进行解析
 * 当解析发生冲突的时候将会使用第一个{@link DataDeserializer}产生的结果
 *
 * @param <ResponseType> {@link ResponseData}或其子类
 * @param <DataType> json数据中data字段所代表的类的type
 *
 * Created by congxiaoyao on 2016/7/16.
 */
public abstract class BaseResponseDataDeserializer<ResponseType extends ResponseData, DataType> implements
        JsonDeserializer<ResponseType> {

    private LinkedList<DataDeserializer<DataType>> customDeserializers;

    public BaseResponseDataDeserializer() {
        customDeserializers = new LinkedList<>();
    }

    public BaseResponseDataDeserializer(DataDeserializer<DataType>... dataDeserializers) {
        this();
        for (DataDeserializer dataDeserializer : dataDeserializers) {
            customDeserializers.addLast(dataDeserializer);
        }
    }

    @Override
    public ResponseType deserialize(JsonElement json, Type typeOfT,
                                    JsonDeserializationContext context)
            throws JsonParseException {
        ResponseType result = getEmptyResponseData();
        JsonObject responseData = json.getAsJsonObject();
        int status = responseData.get("status").getAsInt();
        //status是1说明有问题
        if (status == 1) {
            result.setStatus(1);
            result.setCode(responseData.get("code").getAsInt());
            result.setMessage(DeserializeHelper.getMessage(responseData));
            return result;
        }
        result.setStatus(0);
        String message = DeserializeHelper.getMessage(responseData);
        result.setMessage(message);
        //先尝试使用自定义的解析规则解析
        DataType data = customDeserializeData(responseData, typeOfT, context);
        if (data == null)
            //不行才用默认规则解析
            data = defaultDeserializeData(responseData, typeOfT, context);
        result.setData(data);
        return result;
    }

    /**
     * 尝试使用类内维护的自定义的解析规则解析json数据中的data字段
     *
     * @param responseData       代表整个json数据的JsonObject
     * @param typeOfResponseData responseData所代表的类型 一般为那三种基本类型的一种
     * @param context
     * @return 一旦有一个DataDeserializer解析出了数据将返回他的结果
     */
    protected DataType customDeserializeData(JsonObject responseData, Type typeOfResponseData,
                                             JsonDeserializationContext context) {
        for (DataDeserializer<DataType> customDeserializer : customDeserializers) {
            DataType data = customDeserializer.deserializeData(responseData,
                    typeOfResponseData, context);
            if (data != null) {
                return data;
            }
        }
        return null;
    }

    /**
     * 注册自定义的解析器
     *
     * @param dataDeserializer
     */
    public void addCustomDeserializer(DataDeserializer dataDeserializer) {

        customDeserializers.add(dataDeserializer);
    }

    /**
     * 获得一个空的ResponseType
     * 返回值的类型只能为{@link ResponseData}或其子类中的一种
     *
     * @return
     */
    protected abstract ResponseType getEmptyResponseData();

    /**
     * 使用Gson默认的规则解析json数据中的data字段
     *
     * @param responseData
     * @param typeOfResponseData
     * @param context
     * @return
     */
    protected abstract DataType defaultDeserializeData(JsonObject responseData,
                                                       Type typeOfResponseData,
                                                       JsonDeserializationContext context);
}
