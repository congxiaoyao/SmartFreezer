package com.congxiaoyao.segmenterror.request.gson;

import com.congxiaoyao.segmenterror.response.PagedBeanList;
import com.congxiaoyao.segmenterror.response.ResponseData;
import com.congxiaoyao.segmenterror.response.ResponseListData;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;

import java.lang.reflect.Type;
import java.util.List;

/**
 * SegmentFault服务器返回的数据纷繁复杂，大体上抽象为三类对象
 * {@link ResponseData} {@link ResponseListData} {@link ResponsePagedListData}
 * 这三类对象都是泛型对象 其中后两个是第一个的子类 具体可查看三个类的注释
 *
 * 在反序列化的过程中，Gson提供的解析规则并不能完全满足要求
 * 对于返回的json数据的data字段，有些需要我们亲自干预规则 于是我们将data的解析抽取出来方便维护
 *
 * 如果需要干预{@link ResponseData}的解析，请直接返回data所代表的那种类型(任意类型)
 * 如果需要干预{@link ResponseListData}的解析，请返回为{@link List}类型
 * 如果需要干预{@link ResponsePagedListData}的解析，请返回{@link PagedBeanList}类型
 *
 * 可以将接口的实现类传递给{@link BaseResponseDataDeserializer}或其子类 即可实现自定义的解析功能
 *
 * Created by congxiaoyao on 2016/7/16.
 */
public interface DataDeserializer<DataType> {

    /**
     *
     * @param responseData 代表整个json数据的JsonElement
     * @param typeOfResponseData 将这一整个json数据解析成什么类型的对象 如ResponsePagedListData<Question>
     * @param context 帮助解析的JsonDeserializationContext
     * @return json数据中的data字段所代表的对象 如果返回null 则解析无效
     */
    DataType deserializeData(JsonObject responseData, Type typeOfResponseData,
                             JsonDeserializationContext context);


}
