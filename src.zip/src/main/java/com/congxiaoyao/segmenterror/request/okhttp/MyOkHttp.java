package com.congxiaoyao.segmenterror.request.okhttp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.congxiaoyao.segmenterror.request.retrofit2.adapter.rxjava.HttpException;
import com.congxiaoyao.segmenterror.response.exception.ResponseException;
import com.squareup.picasso.Downloader;

import okhttp3.*;
import rx.Observable;
import rx.schedulers.Schedulers;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 自定义了cookie管理的单例的OkHttpClient，虽然不一定用得到cookie，但先写着呗
 *
 * Created by congxiaoyao on 2016/6/27.
 */
public class MyOkHttp {

    private static OkHttpClient okHttpClient;
    private static Context context;

    //TODO 别忘了把DEBUG删掉
    public static boolean DEBUG = false;

    private static final Map<String, List<Cookie>> cookiesStore = new HashMap<>();

    public static OkHttpClient getInstance() {
        if (okHttpClient == null) {
            synchronized (MyOkHttp.class) {
                if (okHttpClient == null) {
                    okHttpClient = new OkHttpClient.Builder().cookieJar(new CookieJar() {
                        @Override
                        public void saveFromResponse(HttpUrl httpUrl, List<Cookie> list) {
                            cookiesStore.put(httpUrl.host(), list);
                        }

                        @Override
                        public List<Cookie> loadForRequest(HttpUrl httpUrl) {
                            List<Cookie> cookies = cookiesStore.get(httpUrl.host());
                            return cookies == null ? Collections.EMPTY_LIST : cookies;
                        }
                    }).addInterceptor(chain -> {
                        if (!hasNetwork()) {
                            throw new ResponseException(ResponseException.MSG_NULL_NETWORK_ERROR);
                        }
//                        try {
//                            Thread.sleep(3000);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
                        Request request = chain.request().newBuilder()
                                .addHeader("User-Agent", "SegmentFault for Android v3.2.4 VCODE:53")
                                .addHeader("X-Version", "2").build();
                        Response response = chain.proceed(request);
                        return response;
                    }).build();

                }
            }
        }
        return okHttpClient;
    }

    /**
     * 封装了一下post请求
     * 将post请求的返回值处理为Observable<String>以便通过rxjava的方式做后续处理
     * @param url 请求的地址
     * @param params 见{@link Param}注释
     * @return
     */
    public static Observable<String> post(String url, Param... params) {
        if (params == null || params.length == 0) return get(url);
        Observable<String> observable = Observable.create(subscriber -> {
            FormBody.Builder formBodyBuilder = new FormBody.Builder();
            for (Param param : params) {
                formBodyBuilder.add(param.key, param.value);
            }
            FormBody formBody = formBodyBuilder.build();
            try {
                Response response = getInstance()
                        .newCall(new Request.Builder()
                                .url(url).post(formBody).build())
                        .execute();
                String string = response.body().string();
                subscriber.onNext(string);
                subscriber.onCompleted();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        return observable.subscribeOn(Schedulers.io());
    }

    /**
     * 封装了get方式的http请求
     * 将get请求的返回值处理为Observable<String>以便通过rxjava的方式做后续处理
     * @param url
     * @return
     */
    public static Observable<String> get(String url) {
        Observable<String> observable= Observable.create(subscriber -> {
            try {
                ResponseBody body = getInstance().newCall(new Request.Builder().url(url).build()).execute().body();
                String string = body.string();
                subscriber.onNext(string);
                subscriber.onCompleted();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        return observable.subscribeOn(Schedulers.io());
    }

    /**
     * 封装了get方式的http请求
     * 将get请求的返回值处理为Observable<Response>以便通过rxjava的方式做后续处理
     *
     * @param url
     * @return
     */
    public static Observable<Response> getAsResponse(String url) {
        Observable<Response> observable = Observable.create(subscriber -> {
            try {
                Response response = getInstance().newCall(new Request.Builder().url(url).build())
                        .execute();
                subscriber.onNext(response);
                subscriber.onCompleted();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        return observable.subscribeOn(Schedulers.io());
    }


    /**
     * 同上，参数变为{@link Request}对象
     * @param request
     * @return
     */
    public static Observable<String> get(Request request) {
        Observable<String> observable= Observable.create(subscriber -> {
            try {
                ResponseBody body = getInstance().newCall(request).execute().body();
                String string = body.string();
                subscriber.onNext(string);
                subscriber.onCompleted();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        return observable.subscribeOn(Schedulers.io());
    }

    /**
     * post请求时提交的键值对，直接通过构造方法构造即可
     */
    public static class Param{
        public String key;
        public String value;

        public Param(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }

    /**
     * 判断是否有网络连接

     * @return
     */
    private static boolean hasNetwork() {
        if(DEBUG) return true;
        if (context == null) return false;
        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] networks = connectivityManager.getAllNetworkInfo();
        for (NetworkInfo network : networks) {
            if (network.getState() == NetworkInfo.State.CONNECTED) {
                return true;
            }
        }
        return false;
    }

    public static void setContext(Context context) {
        MyOkHttp.context = context;
    }

    public static void release() {
        MyOkHttp.context = null;
        MyOkHttp.okHttpClient = null;
    }

}
