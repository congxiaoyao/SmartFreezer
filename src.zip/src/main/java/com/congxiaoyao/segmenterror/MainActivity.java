package com.congxiaoyao.segmenterror;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.articlelist.ArticleListFragment;
import com.congxiaoyao.segmenterror.articlelist.ArticlePresenter;
import com.congxiaoyao.segmenterror.discover.DiscoverFragment;
import com.congxiaoyao.segmenterror.discover.DiscoverPresenter;
import com.congxiaoyao.segmenterror.helpers.MainToolbarHelper;
import com.congxiaoyao.segmenterror.helpers.NavigationHeaderHelper;
import com.congxiaoyao.segmenterror.helpers.NavigationHelper;
import com.congxiaoyao.segmenterror.navigation.NavigationPresenter;
import com.congxiaoyao.segmenterror.navigation.NavigationViewHandler;
import com.congxiaoyao.segmenterror.questiondetail.QuestionDetailActivity;
import com.congxiaoyao.segmenterror.questionlist.QuestionListFragment;
import com.congxiaoyao.segmenterror.questionlist.QuestionPresenter;
import com.congxiaoyao.segmenterror.utils.DisplayUtils;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "cxy";
    public static final int CODE_REQUEST_LOGIN = 0;

    private QuestionPresenter questionPresenter;
    private ArticlePresenter articlePresenter;
    private DiscoverPresenter discoverPresenter;
    private NavigationPresenter navigationPresenter;

    private QuestionListFragment questionListFragment;
    private ArticleListFragment articleListFragment;
    private DiscoverFragment discoverFragment;
    private NavigationViewHandler navigationViewHandler;

    private int currentPosition = 0;

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        MainToolbarHelper toolbarHelper = new MainToolbarHelper(toolbar);
        toolbarHelper.changeToQuestionSpinner();

        //DrawerLayout
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        //NavigationView
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        NavigationHelper navigationHelper = new NavigationHelper(navigationView,
                R.menu.navigation, R.layout.nav_main, R.layout.nav_header);
        NavigationHeaderHelper navigationHeader = new NavigationHeaderHelper(navigationHelper
                .getHeaderView());

        //presenters&fragment
        questionListFragment = new QuestionListFragment();
        questionPresenter = new QuestionPresenter(questionListFragment);
        articleListFragment = new ArticleListFragment();
        articlePresenter = new ArticlePresenter(articleListFragment);
        discoverFragment = new DiscoverFragment();
        discoverPresenter = new DiscoverPresenter(discoverFragment);
        navigationViewHandler = new NavigationViewHandler(navigationHelper, navigationHeader);
        navigationPresenter = new NavigationPresenter(navigationViewHandler);

        //fab
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        //ViewPager&TabLayout
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        viewPager.setAdapter(new ViewPagerAdapter(getSupportFragmentManager()));
        viewPager.setOffscreenPageLimit(3);
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setSelectedTabIndicatorColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        tabLayout.setSelectedTabIndicatorHeight(DisplayUtils.dp2px(this, 4));
        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener(){
            @Override
            public void onPageSelected(int position) {
                currentPosition = position;
                if (position == 2) {
                    fab.setVisibility(View.GONE);
                    toolbarHelper.changeToText("发现");
                    return;
                } else if (position == 1) {
                    toolbarHelper.changeToArticleSpinner();
                } else if (position == 0) {
                    toolbarHelper.changeToQuestionSpinner();
                }
                if (fab.getVisibility() != View.VISIBLE) {
                    fab.setVisibility(View.VISIBLE);
                }
            }
        });

        //fab点击上划
        fab.setOnClickListener(v -> {
            if (currentPosition == 0) {
                questionListFragment.scrollToTop();
            } else if (currentPosition == 1) {
                articleListFragment.scrollToTop();
            }
            int dis = (int) fab.getTag();
            fab.animate().translationY(dis).setDuration(200).start();
        });

        //spinner与fragment联动
        toolbarHelper.onSelect((type,position)->{
            if (type == MainToolbarHelper.TYPE_SPINNER_QUESTION) {
                switch (position) {
                    case 0:questionPresenter.changeToNewest();
                        break;
                    case 1:questionPresenter.changeToHottest();
                        break;
                    case 2:questionPresenter.changeToUnAnswered();
                        break;
                    default:
                        break;
                }
            } else if (type == MainToolbarHelper.TYPE_SPINNER_ARTICLE) {
                switch (position) {
                    case 0:articlePresenter.changeToRecommended();
                        break;
                    case 1:articlePresenter.changeToNewest();
                        break;
                    case 2:articlePresenter.changeToHottest();
                        break;
                    default:
                        break;
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CODE_REQUEST_LOGIN) {
            if (resultCode == LoginActivity.CODE_RESULT_SUCCESS) {
                //如果登录成功后返回此activity 则立即刷新NavigationView
                navigationPresenter.clearTimer();
                Me me = Me.fromSharedPreferences(this);
                navigationViewHandler.setInfo(me);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_search) {
//            startActivity(new Intent(this, QuestionDetailActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");
        navigationPresenter.subscribe();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        navigationPresenter.unSubscribe();
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {

        private Fragment[] fragments;
        private String[] titles;

        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
            fragments = new Fragment[3];
            fragments[0] = questionListFragment;
            fragments[1] = articleListFragment;
            fragments[2] = discoverFragment;

            titles = new String[]{"问题", "文章", "发现"};
        }

        @Override
        public Fragment getItem(int position) {
            return fragments[position];
        }

        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }
    }
}