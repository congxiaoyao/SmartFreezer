package com.congxiaoyao.segmenterror.navigation;

import com.congxiaoyao.segmenterror.Me;
import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenter;
import com.congxiaoyao.segmenterror.mvpbase.view.LoadableView;
import com.congxiaoyao.segmenterror.response.beans.User;

/**
 * Created by congxiaoyao on 2016/8/22.
 */
public interface NavigationContract {

    interface View extends LoadableView<Presenter> {

        void setInfo(User user);

        void setInfo(Me me);

        void setUnLogin();
    }


    interface Presenter extends BasePresenter {

        void changeTheme();

        void jumpToActivity(Class activityClass);

        void jumpToLogin();

        void clearTimer();
    }

}
