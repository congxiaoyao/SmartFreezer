package com.congxiaoyao.segmenterror.navigation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.LoginActivity;
import com.congxiaoyao.segmenterror.MainActivity;
import com.congxiaoyao.segmenterror.Me;
import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenterImpl;
import com.congxiaoyao.segmenterror.request.UserRequest;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.utils.TAG;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

/**
 * 请在activity或fragment的resume方法中调用订阅方法显示数据
 *
 * Created by congxiaoyao on 2016/8/22.
 */
public class NavigationPresenter extends BasePresenterImpl<NavigationContract.View> implements NavigationContract.Presenter {

    private final Me me;
    private long lastSubscribeTime = 0;

    public NavigationPresenter(NavigationContract.View view) {
        super(view);
        me = Me.fromSharedPreferences(view.getContext());
        //一上来就先显示SharedPreference中存储的数据
        view.setInfo(me);
    }

    /**
     * 切换主题
     */
    @Override
    public void changeTheme() {
        //临时代码 暂时不考虑切换主题的功能
        Toast.makeText(view.getContext(), "要啥自行车！！", Toast.LENGTH_SHORT).show();
    }

    /**
     * 跳转Activity
     * @param activityClass
     */
    @Override
    public void jumpToActivity(Class activityClass) {
        view.getContext().startActivity(new Intent(view.getContext(), activityClass));
    }

    @Override
    public void jumpToLogin() {
        ((AppCompatActivity) view.getContext())
                .startActivityForResult(new Intent(view.getContext(),
                        LoginActivity.class), MainActivity.CODE_REQUEST_LOGIN);
    }

    @Override
    public void clearTimer() {
        lastSubscribeTime = 0;
    }

    /**
     * 获取用户信息保存并显示在view上
     */
    @Override
    public void subscribe() {
        view.showLoading();

        //如果没有token直接return
        // getTokenOrDispatchException函数会自动以未登录错误触发错误分发机制
        String token;
        if ((token = exceptionDispatcher.getTokenOrDispatchException(view.getContext())) == null) return;

        //如果刷新过于频繁则忽略 (10分钟)
        long now = System.currentTimeMillis();
        if (now - lastSubscribeTime < 10 * 60 * 1000){
            view.hideLoading();
            return;
        }

        //真正开始拉数据
        Subscription subscribe = SERetrofit.create(UserRequest.class)
                .me(token)
                .compose(ResponsePreProcess::dataToBean)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(user -> {
                    view.setInfo(user);
                    view.hideLoading();
                }, exceptionDispatcher::dispatchException);
        subscriptions.add(subscribe);
        lastSubscribeTime = now;
    }

    /**
     * 网络请求出错展示SharedPreference中的信息
     * @param throwable
     */
    @Override
    public void onDispatchException(Throwable throwable) {
        view.hideLoading();
        view.setUnLogin();
        view.setInfo(me);
    }

    /**
     * 如果是未登录错误则不要显示本地SharedPreference中的信息
     * @param reason
     * @return
     */
    @Override
    public boolean onUnLogin(String reason) {
        Me.clearWithoutEmail(view.getContext());
        view.setUnLogin();
        return true;
    }
}
