package com.congxiaoyao.segmenterror.navigation;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.View;

import com.congxiaoyao.segmenterror.Me;
import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.SettingsActivity;
import com.congxiaoyao.segmenterror.answersoutline.AnswersOutlineActivity;
import com.congxiaoyao.segmenterror.helpers.NavigationHeaderHelper;
import com.congxiaoyao.segmenterror.helpers.NavigationHelper;
import com.congxiaoyao.segmenterror.response.beans.User;
import com.congxiaoyao.segmenterror.personaldetails.PersonalDetailActivity;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

/**
 * Created by congxiaoyao on 2016/8/22.
 */
public class NavigationViewHandler implements NavigationContract.View {

    private NavigationContract.Presenter presenter;
    private NavigationHelper navigationHelper;
    private NavigationHeaderHelper navigationHeader;

    public NavigationViewHandler(NavigationHelper navigationHelper,
                                 NavigationHeaderHelper navigationHeader) {
        this.navigationHelper = navigationHelper;
        this.navigationHeader = navigationHeader;

        navigationHeader.userName.setOnClickListener(v -> navigationHeader.avatar.callOnClick());
        navigationHeader.avatar.setOnClickListener(v -> {
            String token = Me.token(navigationHeader.getContext());
            if (token == null) {
                presenter.jumpToLogin();
            }else {
                presenter.jumpToActivity(PersonalDetailActivity.class);
            }
        });

        navigationHeader.qrCode.setOnClickListener(v -> {
            showLoading();
        });

        navigationHeader.qrScan.setOnClickListener(v -> {
            hideLoading();
        });

        navigationHelper.onItemSelected(id -> {
            switch (id) {
                case R.id.menu_bookmark:
                    break;
                case R.id.menu_following:
                    break;
                case R.id.menu_invited:
                    break;
                case R.id.menu_my_question:
                    break;
                case R.id.menu_my_answer:
                    presenter.jumpToActivity(AnswersOutlineActivity.class);
                    break;
                case R.id.menu_my_article:
                    break;
                case R.id.menu_outline_article:
                    break;
                case R.id.menu_theme:
                    presenter.changeTheme();
                    break;
                case R.id.menu_setting:
                    presenter.jumpToActivity(SettingsActivity.class);
                    break;
            }
        });
    }

    @Override
    public void hideLoading() {
        navigationHelper.getProgressBar().setVisibility(View.GONE);
    }

    @Override
    public void showLoading() {
        navigationHelper.getProgressBar().setVisibility(View.VISIBLE);
    }

    public void setInfo(Me me) {
        if (me.getRank() != null) {
            navigationHeader.reputation.setText(me.getRank());
        }
        if (me.getName() != null) {
            navigationHeader.userName.setText(me.getName());
        }
        if (me.getAvatarUrl() != null) {
            Picasso.with(getContext())
                    .load(me.getAvatarUrl())
                    .placeholder(R.drawable.ic_avatar)
                    .error(R.drawable.ic_avatar)
                    .networkPolicy(NetworkPolicy.OFFLINE, NetworkPolicy.OFFLINE)
                    .into(navigationHeader.avatar);

        }
    }

    @Override
    public void setInfo(User user) {
        navigationHelper.updateItemContent(R.id.menu_my_answer, user.getAnswers());
        navigationHelper.updateItemContent(R.id.menu_my_question, user.getQuestions());
        navigationHelper.updateItemContent(R.id.menu_my_article, user.getArticles());
        navigationHeader.badge.setText(String.valueOf(user.getBadges()));
        navigationHeader.reputation.setText(user.getRank());
        navigationHeader.liked.setText(String.valueOf(user.getLikedVotes()));
        navigationHeader.userName.setText(user.getName());
        Picasso.with(getContext())
                .load(user.getAvatarUrl())
                .placeholder(R.drawable.ic_avatar)
                .into(navigationHeader.avatar);
    }

    @Override
    public void setUnLogin() {
        navigationHelper.updateItemContent(R.id.menu_my_answer, 0);
        navigationHelper.updateItemContent(R.id.menu_my_question, 0);
        navigationHelper.updateItemContent(R.id.menu_my_article, 0);
        navigationHeader.badge.setText("0");
        navigationHeader.reputation.setText("0");
        navigationHeader.liked.setText("0");
        navigationHeader.userName.setText("登录/注册");
        navigationHeader.avatar.setImageDrawable(ContextCompat
                .getDrawable(getContext(), R.drawable.ic_avatar));
    }

    @Override
    public void setPresenter(NavigationContract.Presenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return navigationHeader.avatar.getContext();
    }
}
