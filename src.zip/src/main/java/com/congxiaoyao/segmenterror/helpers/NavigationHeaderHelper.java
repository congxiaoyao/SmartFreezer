package com.congxiaoyao.segmenterror.helpers;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.congxiaoyao.segmenterror.R;

/**
 * 侧滑栏的头部view的助手类 主要为了处理两个顶部按钮显示的位置在不同版本上的兼容性问题
 *
 * 同时提供了下findViewById的功能
 *
 * Created by congxiaoyao on 2016/7/20.
 */
public class NavigationHeaderHelper {

    private View headerView;

    public TextView reputation;
    public TextView badge;
    public TextView liked;
    public TextView userName;

    public View qrCode;
    public View qrScan;

    public ImageView avatar;

    /**
     * 构造函数中处理按钮位置兼容性问题
     * @param headerView 整个头部view
     */
    public NavigationHeaderHelper(View headerView) {
        this.headerView = headerView;
        this.qrCode = headerView.findViewById(R.id.iv_qr_code);
        this.qrScan = headerView.findViewById(R.id.iv_qr_scan);
        reputation = (TextView) headerView.findViewById(R.id.tv_reputation);
        badge = (TextView) headerView.findViewById(R.id.tv_badge);
        liked = (TextView) headerView.findViewById(R.id.tv_liked);
        userName = (TextView) headerView.findViewById(R.id.tv_user_name);

        avatar = (ImageView) headerView.findViewById(R.id.iv_avatar);
    }

    public Context getContext() {
        return headerView.getContext();
    }
}