package com.congxiaoyao.segmenterror.helpers;

import android.support.v7.widget.ActionMenuView;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.utils.DisplayUtils;

import java.util.ArrayList;
import java.util.List;

import rx.functions.Action2;

/**
 * 请配合布局文件toolbar_main.xml使用
 * spinner中的数据存放在arrays.xml文件中 使用时请配置
 *
 * 此类主要负责处理显示样式 如 overflow icon 按钮宽度 背景 popup位置 宽度 内容等
 * 提供spinner 与 textView的切换功能
 *
 * 提供对spinner的点击监听 见{@link MainToolbarHelper#onSelect}
 *
 * 关于左侧的导航按钮 这里只对其设置了背景颜色 样式请手动更改
 *
 * Created by congxiaoyao on 2016/7/22.
 */
public class MainToolbarHelper extends ToolbarHelper{

    public static final int TYPE_SPINNER_QUESTION = 0;
    public static final int TYPE_SPINNER_ARTICLE = 1;
    public static final int TYPE_TITTLE = 2;
    private int currentType = -1;
    private int[] currentChoose = {0, 0};

    private AppCompatSpinner spinner;
    private ArrayAdapter<CharSequence> adapter;

    private CharSequence[] questionTypes;
    private CharSequence[] articleTypes;
    private List<CharSequence> popupData;

    private Action2<Integer,Integer> onSelect;

    public MainToolbarHelper(Toolbar toolbar) {
        super(toolbar);

        //将三个点的overflow按钮变成加号 别切设置成等宽的
        toolbar.setOverflowIcon(getDrawable(R.drawable.ic_add));
        ActionMenuView actionMenuView = getActionMenuView();
        actionMenuView.post(()->{
            int childCount = actionMenuView.getChildCount();
            AppCompatImageView overflowBtn = (AppCompatImageView) actionMenuView
                    .getChildAt(childCount - 1);
            int size = DisplayUtils.measureView(actionMenuView.getChildAt(childCount - 2)).x;
            overflowBtn.getLayoutParams().width = size;
            overflowBtn.setPadding(0,0,0,0);
            actionMenuView.requestLayout();
        });

        //spinner部分
        spinner = (AppCompatSpinner) toolbar.findViewById(R.id.spinner);

        //准备数据
        questionTypes = context.getResources().getTextArray(R.array.spinner_question);
        articleTypes = context.getResources().getTextArray(R.array.spinner_article);

        popupData = new ArrayList<>(questionTypes.length);
        adapter = new ArrayAdapter<>(context, R.layout.item_spinner, popupData);
        adapter.setDropDownViewResource(R.layout.item_popup);
        spinner.setAdapter(adapter);
        changeToQuestionSpinner();
        //设置监听
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (onSelect != null) {
                    currentChoose[currentType] = position;
                    onSelect.call(currentType, position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        //设置popup菜单宽度位置
        spinner.post(()->{
            spinner.setDropDownWidth(spinner.getWidth());
            spinner.setDropDownVerticalOffset((spinner.getHeight() - toolbar.getHeight()) / 2);
        });
    }

    /**
     * toolbar上导航按钮右侧变为文字
     * @param titleText
     */
    public void changeToText(String titleText) {
        if (currentType == TYPE_TITTLE) return;
        toolbar.setTitle(titleText);
        if (toolbar.getChildCount() == 1) return;
        getTittleView().setVisibility(View.VISIBLE);
        spinner.setVisibility(View.GONE);
        currentType = TYPE_TITTLE;
    }

    /**
     * toolbar上导航按钮右侧变为显示spinner
     */
    public void changeToQuestionSpinner() {
        if (currentType == TYPE_SPINNER_QUESTION) return;
        changeToSpinner(questionTypes);
        currentType = TYPE_SPINNER_QUESTION;
        spinner.setSelection(currentChoose[currentType]);
    }

    /**
     * toolbar上导航按钮右侧变为显示spinner
     */
    public void changeToArticleSpinner() {
        if (currentType == TYPE_SPINNER_ARTICLE) return;
        changeToSpinner(articleTypes);
        currentType = TYPE_SPINNER_ARTICLE;
        spinner.setSelection(currentChoose[currentType]);
    }

    /**
     * 获取当前spinner中内容的类型
     * {@link MainToolbarHelper#TYPE_SPINNER_QUESTION}
     * {@link MainToolbarHelper#TYPE_SPINNER_ARTICLE}
     * {@link MainToolbarHelper#TYPE_TITTLE}
     * @return
     */
    public int getCurrentType() {
        return currentType;
    }

    /**
     * 返回当前spinner选择的项
     * 如果当前没有spinner 返回-1
     *
     * @return
     */
    public int getCurrentChoose() {
        if (currentType == TYPE_TITTLE) return -1;
        return currentChoose[currentType];
    }

    /**
     * 设置spinner点击监听
     * 回调函数第一个参数代表 type 第二个参数代表 position
     * @param onSelect
     */
    public void onSelect(Action2<Integer,Integer> onSelect) {
        this.onSelect = onSelect;
    }

    private void changeToSpinner(CharSequence[] types) {
        TextView tittleView = getTittleView();
        if (tittleView != null) tittleView.setVisibility(View.GONE);
        spinner.setVisibility(View.VISIBLE);
        popupData.clear();
        for (CharSequence data : types) {
            popupData.add(data);
        }
        adapter.notifyDataSetChanged();
    }

    /**
     * 获取显示标题的TextView
     * @return
     */
    private TextView getTittleView() {
        int childCount = toolbar.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View view = toolbar.getChildAt(i);
            if (view instanceof TextView) {
                return (TextView) view;
            }
        }
        return null;
    }

    public AppCompatSpinner getSpinner() {
        return spinner;
    }
}