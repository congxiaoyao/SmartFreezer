package com.congxiaoyao.segmenterror.helpers;

import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;

import com.congxiaoyao.segmenterror.R;

/**
 * 为两种bottomBar提供基本操作如设置文字 图标 监听器 并提供字符串处理操作
 * 本类需要依赖资源文件 R.layout.bottom_bar
 *
 * Created by congxiaoyao on 2016/8/3.
 */
public abstract class BottomBarHelper {

    protected static final int intervalCount = 1;      //内容跟数字之间的空格数
    protected static final int paddingCount = 1;       //内容跟图标之间的空格数

    protected static String intervalSpace = "";
    protected static String paddingSpace = "";

    protected int unCheckedColor;
    protected int checkedColor;

    static {
        int i = 0; while (i++ < intervalCount) intervalSpace += " ";
        i = 0; while (i++ < paddingCount) paddingSpace += " ";
    }

    protected View bar;

    protected View[] buttons;
    protected CheckedTextView[] textViews;

    public BottomBarHelper(View bottomBar) {
        this.bar = bottomBar;

        buttons = new View[3];
        buttons[0] = bar.findViewById(R.id.bb_left_btn);
        buttons[1] = bar.findViewById(R.id.bb_center_btn);
        buttons[2] = bar.findViewById(R.id.bb_right_btn);

        textViews = new CheckedTextView[3];
        textViews[0] = (CheckedTextView) ((ViewGroup) buttons[0]).getChildAt(0);
        textViews[1] = (CheckedTextView) ((ViewGroup) buttons[1]).getChildAt(0);
        textViews[2] = (CheckedTextView) ((ViewGroup) buttons[2]).getChildAt(0);

        unCheckedColor = textViews[0].getCurrentTextColor();
        checkedColor = ContextCompat.getColor(bar.getContext(), R.color.colorLightGreen);

        //默认状态
        for (int i = 0; i < 2; i++) {
            setIconAndText(getIconByState(i), createButtonText(0, i), i);
        }
    }

    /**
     * 获取指定按钮当前状态下的icon
     * @param index 左中右为别为0 1 2
     * @return
     */
    protected abstract Drawable getIconByState(int index);

    /**
     * 获取指定按钮的所代表的功能的文字
     * 如 收藏 评论 关注 赞等等
     * @param index 左中右为别为0 1 2
     * @return
     */
    protected abstract String getTitleByIndex(int index);

    /**
     * 设置图标
     * @param drawable
     * @param index 左中右为别为0 1 2
     */
    public void setIcon(Drawable drawable, int index) {
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        textViews[index].setCompoundDrawables(drawable, null, null, null);
//        textViews[index].setCompoundDrawablesRelativeWithIntrinsicBounds
//                (drawable, null, null, null);
    }

    /**
     * 设置显示的文字
     * @param text
     * @param index 左中右为别为0 1 2
     */
    public void setText(String text, int index) {
        textViews[index].setText(text);
    }

    /**
     * 设置文字颜色
     * @param color
     * @param index 左中右为别为0 1 2
     */
    public void setTextColor(int color, int index) {
        textViews[index].setTextColor(color);
    }

    /**
     * 设置文字和图标
     * @param icon
     * @param text
     * @param index 左中右为别为0 1 2
     */
    public void setIconAndText(Drawable icon, String text, int index) {
        setIcon(icon, index);
        setText(text, index);
    }

    /**
     * 设置选中状态 只是为了标记 虽然没有什么显示上的效果
     * @param checked
     * @param index 左中右为别为0 1 2
     */
    public void setCheckedByIndex(boolean checked, int index) {
        textViews[index].setChecked(checked);
    }

    /**
     * 设置状态为被选中了
     * @param index 左中右为别为0 1 2
     */
    public void setCheckedByIndex(int index) {
        setCheckedByIndex(true, index);
    }

    /**
     * 设置状态为没被选中
     * @param index 左中右为别为0 1 2
     */
    public void setUnCheckedByIndex(int index) {
        setCheckedByIndex(false, index);
    }

    public String getText(int index) {
        return textViews[index].getText().toString();
    }

    /**
     *
     * @param index 左中右为别为0 1 2
     * @return
     */
    public boolean isChecked(int index) {
        return textViews[index].isChecked();
    }

    private String createButtonText(String text, int count) {
        return paddingSpace + (count == 0 ? "" : count) + intervalSpace + text;
    }

    /**
     * 给定按钮的index以及上面显示的数字即可生成按钮当前的文字
     * @param count
     * @param index
     * @return
     */
    protected String createButtonText(int count, int index) {
        return createButtonText(getTitleByIndex(index), count);
    }

    /**
     * 初始化一个按钮 设置其文字、图标、颜色 同时标记其为选中状态
     *
     * @param text  注意这里就直接给按钮设置文字 如果有数字 请带上数字
     * @param index 左中右为别为0 1 2
     */
    protected void initButtonWithCheck(String text, int index) {
        setCheckedByIndex(index);
        setTextColor(checkedColor, index);
        setIconAndText(getIconByState(index), text, index);
    }

    /**
     * 初始化一个按钮 设置其文字、图标、颜色 同时标记其为非选中状态
     *
     * @param text  注意这里就直按钮俺就设置文字 如果有数字 请带上数字
     * @param index 左中右为别为0 1 2
     */
    protected void initButtonWithUnCheck(String text, int index) {
        setUnCheckedByIndex(index);
        setTextColor(unCheckedColor, index);
        setIconAndText(getIconByState(index), text, index);
    }

    /**
     * 改变index位置上的按钮的状态 同时改变其显示的文字或背景颜色的等ui效果
     * @param index 左中右为别为0 1 2
     */
    protected void changeButtonStateByIndex(int index) {
        boolean checked = isChecked(index);
        if (checked) {
            setUnCheckedByIndex(index);
            reduce(index);
            setTextColor(unCheckedColor, index);
        } else {
            setCheckedByIndex(index);
            add(index);
            setTextColor(checkedColor, index);
        }
        setIcon(getIconByState(index), index);
    }

    /**
     * 给某个按钮的数字加1
     * @param index
     */
    protected void add(int index) {
        String text = getText(index);
        int count = decodeNumber(text);
        text = setNumber(text, count + 1);
        setText(text, index);
    }

    /**
     * 给某个按钮的数字减1
     * @param index
     */
    protected void reduce(int index) {
        String text = getText(index);
        int count = decodeNumber(text);
        if(count == 0) return;
        text = setNumber(text, count - 1);
        setText(text, index);
    }

    /**
     * 给左按钮设置监听
     * @param listener
     */
    public void onLeftButtonClick(View.OnClickListener listener) {
        buttons[0].setOnClickListener(listener);
    }

    /**
     * 给中按钮设置监听
     * @param listener
     */
    public void onCenterButtonClick(View.OnClickListener listener) {
        buttons[1].setOnClickListener(listener);
    }

    /**
     * 给右按钮设置监听
     * @param listener
     */
    public void onRightButtonClick(View.OnClickListener listener) {
        buttons[2].setOnClickListener(listener);
    }

    public Drawable getDrawable(@DrawableRes int res) {
        return ContextCompat.getDrawable(bar.getContext(), res);
    }

    /**
     * 从字符串中解析数字
     * @param text
     * @return
     */
    public static int decodeNumber(String text) {
        String[] split = trim(text).split(" ");
        if(split.length == 0) return -1;
        if(split.length == 1) return 0;
        return Integer.parseInt(split[0]);
    }

    /**
     * 从字符串中解析内容
     * @param text
     * @return
     */
    public static String decodeContent(String text) {
        String[] split = trim(text).split(" ");
        if(split.length == 0) return null;
        if(split.length == 1) return split[0];
        return split[1];
    }

    /**
     * 给text设置数字部分，如果数字为0 则不显示数字
     * @param text
     * @param number
     * @return
     */
    public static String setNumber(String text, int number) {
        if (number < 0) return null;
        String[] split = trim(text).split(" ");
        if (split.length == 0) return null;
        //没有数字的情况
        if (split.length == 1) {
            if (number == 0) return paddingSpace + text;
            return paddingSpace + number + intervalSpace + split[0];
        }
        //有数字存在的情况
        else {
            if (number == 0) return paddingSpace + split[1];
            return text.replace(split[0], number + "");
        }
    }

    /**
     * 给text设置内容部分
     * @param text
     * @param content
     * @return
     */
    public static String setContent(String text, String content) {
        String[] split = trim(text).split(" ");
        if (split.length == 0) return null;
        if(split.length == 1) return paddingSpace + content;
        return paddingSpace + split[0] + intervalSpace + content;
    }

    /**
     * 去头尾空格 去重复空格
     * @param text
     * @return
     */
    public static String trim(String text) {
        char[] chars = text.toCharArray();
        int pointer = 0;
        while (chars[pointer++] == ' ');
        int i = pointer-1;
        pointer = 0;
        for (; i < chars.length - 1; i++) {
            //没有出现重复
            if (!(chars[i] == ' ' && chars[i + 1] == ' ')) {
                chars[pointer++] = chars[i];
            }
        }
        //如果最后一个不是空格就加进去
        if(chars[i] != ' ') chars[pointer++] = chars[i];
        return new String(chars, 0, pointer);
    }
}