package com.congxiaoyao.segmenterror.helpers;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.ActionMenuView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import java.lang.reflect.Field;

/**
 * 系统中存在两种toolbar 一种是主界面上的toolbar 由子类{@link MainToolbarHelper}维护
 * 另外一种是其他界面上显示的toolbar 这里把两种toolbar都要用到的操作提取出来
 *
 * Created by congxiaoyao on 2016/7/22.
 */
public class ToolbarHelper {

    private static final String TAG = "ToolbarHelper";
    protected Toolbar toolbar;
    protected Context context;

    private ImageButton navButtonView = null;
    private ActionMenuView actionMenuView = null;

    private int navBgColorId = 0;

    public ToolbarHelper(Toolbar toolbar) {
        this.toolbar = toolbar;
        this.context = toolbar.getContext();
    }

    /**
     * 获取toolbar中所有菜单按钮的直接父控件
     * @return
     */
    public ActionMenuView getActionMenuView() {
        if(actionMenuView != null) return actionMenuView;
        ActionMenuView mMenuView = null;
        try {
            Field field = toolbar.getClass().getDeclaredField("mMenuView");
            field.setAccessible(true);
            mMenuView = (ActionMenuView) field.get(toolbar);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
            return null;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return null;
        }
        return actionMenuView = mMenuView;
    }

    /**
     * 获取导航栏按钮
     * @return
     */
    public ImageButton getNavButtonView() {
        if(navButtonView != null) return navButtonView;
        ImageButton mNavButtonView = null;
        try {
            Field field = toolbar.getClass().getDeclaredField("mNavButtonView");
            field.setAccessible(true);
            mNavButtonView = (ImageButton) field.get(toolbar);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
            return null;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return null;
        }
        return navButtonView = mNavButtonView;
    }

    /**
     * 给导航按钮设置ripple背景颜色
     * @param resId
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setNavButtonBackgroundRippleColor(@ColorRes int resId) {
        if (resId == navBgColorId) return;
        Log.d(TAG, "setNavButtonBackgroundRippleColor: you don't need to change it again");
        ImageButton navButtonView = getNavButtonView();
        if (navButtonView == null) return;
        navButtonView.post(()->{
            setRippleBackGroundColor((RippleDrawable) navButtonView.getBackground(), resId);
            navBgColorId = resId;
        });
    }

    /**
     * 给菜单项按钮设置ripple背景色
     * @param resId
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setActionMenuButtonsBackgroundRippleColor(@ColorRes int resId) {
        ActionMenuView menuButtons = getActionMenuView();
        if (menuButtons == null) return;
        menuButtons.post(()->{
            for (int i = 0; i < menuButtons.getChildCount(); i++) {
                View menuButton = menuButtons.getChildAt(i);
                setRippleBackGroundColor((RippleDrawable) menuButton.getBackground(), resId);
            }
        });
    }

    /**
     * 通过资源id获取drawable
     * @param id
     * @return
     */
    public Drawable getDrawable(@DrawableRes int id) {
        return ContextCompat.getDrawable(context, id);
    }

    /**
     * 通过资源id获取颜色
     * @param id
     * @return
     */
    public ColorStateList getColor(@ColorRes int id) {
        return ContextCompat.getColorStateList(context, id);
    }

    /**
     * 给一个ripplebackground设置ripple的颜色
     * @param drawable
     * @param id
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setRippleBackGroundColor(RippleDrawable drawable, @ColorRes int id) {
        drawable.setColor(getColor(id));
    }

}