package com.congxiaoyao.segmenterror.helpers;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.support.annotation.MenuRes;
import android.support.v7.view.ContextThemeWrapper;
import android.support.v7.view.menu.MenuPopupHelper;
import android.support.v7.widget.ListPopupWindow;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.utils.ReflectUtil;

import java.util.List;

import rx.functions.Action1;
import rx.functions.Action2;

/**
 * SegmentFault中toolbar主要分为两种 一种是主界面中出现的toolbar 详细请看{@link MainToolbarHelper}
 * 另一种就是用于分享问题或分享文章的以分享功能为主的toolbar
 *
 * 本类主要解决分享菜单的生成问题 提供标题设置和导航按钮背景色更改
 * 需要配合toolbar_share.xml使用 同时需要一份menu的xml文件来控制几个固定的分享选项
 *
 * 这个类内有两种分享菜单 一个是固定item数量的菜单叫做 fixedPopup
 * 菜单中每个item的title和icon根据菜单资源文件定义 对于每个菜单项的点击监听 可以通过
 * {@link SharedToolbarHelper#onShareMenuSelected} 方法注册实现
 *
 * 另一种分享菜单(sharePopup)用于展示系统中支持分享的应用列表 可以通过
 * {@link SharedToolbarHelper#onShareMenuSelected} 方法监听点击
 * 如果想分享一段文本内容到某个分享菜单中所列出的应用里 请参照
 * {@link SharedToolbarHelper#createShare(String, MenuItem)}
 *
 * Created by congxiaoyao on 2016/7/24.
 */
public class SharedToolbarHelper extends ToolbarHelper {

    private Context context;

    private PopupMenu fixedPopup;
    private PopupMenu sharePopup;
    private MenuPopupHelper fixedHelper;

    private Action1<MenuItem> onFixedMenuSelected;
    private Action2<MenuItem, SharedToolbarHelper> onShareMenuSelected;

    private List<ResolveInfo> resolveInfos;

    /**
     * @param toolbar
     * @param fixedShareMenuId 用于显示微博分享 微信分享之类的菜单的id
     */
    public SharedToolbarHelper(Toolbar toolbar, @MenuRes int fixedShareMenuId) {
        super(toolbar);
        context = toolbar.getContext();

        //初始化fixedPopup 给他设置刚刚得到的数据集、背景、宽高等
        fixedPopup = initFixedPopup(fixedShareMenuId);

        toolbar.post(() -> initShareButton(getActionMenuView().getChildAt(0)));
    }

    /**
     * 设置弹出菜单的背景 模态 数据适配器 宽高 位置 anchorView
     *
     * @param menuRes
     * @return
     */
    private PopupMenu initFixedPopup(@MenuRes int menuRes) {
        PopupMenu popupMenu = new PopupMenu(new ContextThemeWrapper(context,
                R.style.MyactionOverflowMenuStyle), toolbar, Gravity.RIGHT);
        fixedHelper = (MenuPopupHelper) ReflectUtil.getField("mPopup", popupMenu);
        fixedHelper.setForceShowIcon(true);
        popupMenu.getMenuInflater().inflate(menuRes, popupMenu.getMenu());
        MenuItem loadMoreMenu = popupMenu.getMenu().getItem(popupMenu.getMenu().size() - 1);
        popupMenu.setOnMenuItemClickListener(item -> {
            popupMenu.dismiss();
            if (item.getItemId() == loadMoreMenu.getItemId()) {
                showSharePopup();
                return true;
            }
            if (onFixedMenuSelected != null)
                onFixedMenuSelected.call(item);
            return true;
        });
        return popupMenu;
    }

    /**
     * 初始化分享菜单 列出系统中支持分享功能的应用
     * @return
     */
    private PopupMenu initShareMenu() {
        PopupMenu popup = new PopupMenu(context, toolbar, Gravity.RIGHT);
        MenuPopupHelper mPopup = (MenuPopupHelper) ReflectUtil.getField("mPopup", popup);
        mPopup.setForceShowIcon(true);

        //准备 添加 数据集
        Intent intent = new Intent(Intent.ACTION_SEND, null);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.setType("text/plain");
        PackageManager pm = context.getPackageManager();
        resolveInfos = pm.queryIntentActivities(intent,
                PackageManager.COMPONENT_ENABLED_STATE_DEFAULT);
        Menu shareMenuItems = popup.getMenu();
        for (int i = 0; i < resolveInfos.size(); i++) {
            ResolveInfo resolveInfo = resolveInfos.get(i);
            shareMenuItems.add(-1, i, Menu.NONE,
                    resolveInfo.loadLabel(pm)).setIcon(resolveInfo.loadIcon(pm));
        }

        //设置点击监听
        popup.setOnMenuItemClickListener(item -> {
            if (onShareMenuSelected != null) {
                onShareMenuSelected.call(item, this);
            }
            return true;
        });
        return popup;
    }

    /**
     * 给分享按钮添加点击和触摸监听从而实现popupMenu弹出
     * @param shareButton
     */
    private void initShareButton(View shareButton) {
        shareButton.setOnClickListener(v-> fixedPopup.show());
        shareButton.setOnTouchListener(new ListPopupWindow.ForwardingListener(shareButton) {
            @Override
            public ListPopupWindow getPopup() {
                return fixedHelper.getPopup();
            }

            @Override
            public boolean onForwardingStarted() {
                fixedHelper.show();
                return true;
            }

            @Override
            public boolean onForwardingStopped() {
                fixedHelper.dismiss();
                return true;
            }
        });
    }

    private void showSharePopup() {
        if (sharePopup == null) {
            sharePopup = initShareMenu();
        }
        sharePopup.show();
    }

    /**
     * 设置标题
     * @param title
     */
    public void setTitle(String title) {
        toolbar.setTitle(title);
    }

    /**
     * 调用分享功能 分享一段文本
     *
     * @param textToShare
     * @param menuItem
     */
    public void createShare(String textToShare, MenuItem menuItem) {
        if (menuItem.getGroupId() != -1) return;
        ResolveInfo resolveInfo = resolveInfos.get(menuItem.getItemId());
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setComponent(new ComponentName(
                resolveInfo.activityInfo.packageName,
                resolveInfo.activityInfo.name));
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, textToShare);
        shareIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(shareIntent);
    }

    /**
     * 固定分享菜单选择监听(微信分享 微博分享等)
     * @param onFixedMenuSelected 泛型代表了被选中的菜单的id
     */
    public void onFixedMenuSelected(Action1<MenuItem> onFixedMenuSelected) {
        this.onFixedMenuSelected = onFixedMenuSelected;
    }

    /**
     * 系统中支持分享的应用的菜单
     *
     * @param onShareMenuSelected 第一个泛型是点击的菜单
     *                            第二个是Helper自己
     */
    public void onShareMenuSelected(Action2<MenuItem,
            SharedToolbarHelper> onShareMenuSelected) {
        this.onShareMenuSelected = onShareMenuSelected;
    }
}