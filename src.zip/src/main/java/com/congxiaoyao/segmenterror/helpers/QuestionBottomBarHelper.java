package com.congxiaoyao.segmenterror.helpers;

import android.graphics.drawable.Drawable;
import android.view.View;

import com.congxiaoyao.segmenterror.R;

/**
 * 问题界面的底部bar的ui帮助类 给使用者提供这样一种概念
 * bottom bar中的每一个按钮存在一个初始状态 可以通过initXXXButton方法来设置
 * 之后用户的每次点击，相当于切换一次状态 通过changeXXXButtonState方法操作
 *
 * 关于按钮的点击监听 参考父类
 * {@link BottomBarHelper#onLeftButtonClick(View.OnClickListener)}
 * {@link BottomBarHelper#onCenterButtonClick(View.OnClickListener)}
 * {@link BottomBarHelper#onRightButtonClick(View.OnClickListener)}
 * 方法注释
 *
 * Created by congxiaoyao on 2016/8/3.
 */
public class QuestionBottomBarHelper extends BottomBarHelper {

    public QuestionBottomBarHelper(View bottomBar) {
        super(bottomBar);
    }

    /**
     * 初始化关注按钮
     * @param count 关注人数
     * @param checked 是否为选中状态
     */
    public void initFollowButton(int count, boolean checked) {
        String text = createButtonText(count, 0);
        if (checked) {
            initButtonWithCheck(text, 0);
        } else {
            initButtonWithUnCheck(text, 0);
        }
    }

    /**
     * 初始化收藏按钮
     * @param count 收藏人数
     * @param checked 是否为选中状态
     */
    public void initBookMarkButton(int count, boolean checked) {
        String text = createButtonText(count, 1);
        if (checked) {
            initButtonWithCheck(text, 1);
        } else {
            initButtonWithUnCheck(text, 1);
        }
    }

    /**
     * 初始化回答按钮
     * @param checked
     */
    public void initAnswerButton(boolean checked) {
        if (checked) {
            initButtonWithCheck("编辑答案", 2);
        } else {
            initButtonWithUnCheck("撰写答案", 2);
        }
    }

    /**
     * 改变关注按钮状态 如果是已经关注的 调用此函数后会将关注数减1且标记为非选中状态
     */
    public void changeFollowButtonState() {
        changeButtonStateByIndex(0);
    }

    /**
     * 改变收藏按钮状态 如果是已经收藏的 调用此函数后会将关收藏减1且标记为非选中状态
     */
    public void changeBookMarkButtonState() {
        changeButtonStateByIndex(1);
    }

    /**
     * 改变回答按钮的状态
     */
    public void changeAnswerButtonState() {
        boolean checked = isChecked(2);
        if (checked) {
            setUnCheckedByIndex(2);
            setTextColor(unCheckedColor, 2);
            setText("撰写答案", 2);
        } else {
            setCheckedByIndex(2);
            setTextColor(checkedColor, 2);
            setText("编辑答案", 2);
        }
        setIcon(getIconByState(2), 2);
    }

    /**
     * 根据index位置的按钮的状态返回他的图标资源
     * @param index 左中右位分别为0 1 2
     * @return
     */
    @Override
    public Drawable getIconByState(int index) {
        boolean checked = isChecked(index);
        switch (index) {
            case 0:
                if(checked) return getDrawable(R.drawable.follow_checked);
                return getDrawable(R.drawable.follow_normal);
            case 1:
                if(checked) return getDrawable(R.drawable.archive_checked);
                return getDrawable(R.drawable.archive_normal);
            case 2:
                if(checked) return getDrawable(R.drawable.write_checked);
                return getDrawable(R.drawable.write_normal);
        }
        return null;
    }

    @Override
    protected String getTitleByIndex(int index) {
        switch (index) {
            case 0:
                return "关注";
            case 1:
                return "收藏";
            case 2:
                return "撰写答案";
        }
        return null;
    }

}