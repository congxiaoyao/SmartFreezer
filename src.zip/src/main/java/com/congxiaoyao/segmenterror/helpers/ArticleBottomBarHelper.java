package com.congxiaoyao.segmenterror.helpers;

import android.graphics.drawable.Drawable;
import android.view.View;

import com.congxiaoyao.segmenterror.R;

/**
 * Created by congxiaoyao on 2016/8/13.
 */
public class ArticleBottomBarHelper extends BottomBarHelper {

    public ArticleBottomBarHelper(View bottomBar) {
        super(bottomBar);
    }

    /**
     * 初始化like按钮
     * @param count like的人数
     * @param checked 是否为选中状态
     */
    public void initLikeButton(int count, boolean checked) {
        String text = createButtonText(count, 0);
        if (checked) {
            initButtonWithCheck(text, 0);
        } else {
            initButtonWithUnCheck(text, 0);
        }
    }

    /**
     * 初始化收藏按钮
     * @param count 收藏人数
     * @param checked 是否为选中状态
     */
    public void initBookMarkButton(int count, boolean checked) {
        String text = createButtonText(count, 1);
        if (checked) {
            initButtonWithCheck(text, 1);
        } else {
            initButtonWithUnCheck(text, 1);
        }
    }

    /**
     * 初始化评论按钮
     * @param count
     */
    public void initCommentButton(int count) {
        String text = createButtonText(count, 2);
        initButtonWithUnCheck(text, 2);
    }

    /**
     * 改变like按钮状态 如果是已经like的 调用此函数后会将关注数减1且标记为非选中状态
     */
    public void changeLikeButtonState() {
        changeButtonStateByIndex(0);
    }

    /**
     * 改变收藏按钮状态 如果是已经收藏的 调用此函数后会将关收藏减1且标记为非选中状态
     */
    public void changeBookMarkButtonState() {
        changeButtonStateByIndex(1);
    }

    @Override
    public Drawable getIconByState(int index) {
        boolean checked = textViews[index].isChecked();
        switch (index) {
            case 0:
                return getDrawable(checked ? R.drawable.article_like_checked :
                        R.drawable.article_like_unchecked);
            case 1:
                return getDrawable(checked ? R.drawable.article_bookmark_checked :
                        R.drawable.article_bookmark_unchecked);
            case 2:
                return getDrawable(checked ? R.drawable.article_comment :
                        R.drawable.article_comment);
        }
        return null;
    }

    @Override
    public String getTitleByIndex(int index) {
        switch (index) {
            case 0:
                return "赞";
            case 1:
                return "收藏";
            case 2:
                return "评论";
        }
        return null;
    }
}
