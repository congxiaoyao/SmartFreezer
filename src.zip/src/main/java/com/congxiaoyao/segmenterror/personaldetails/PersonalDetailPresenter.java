package com.congxiaoyao.segmenterror.personaldetails;

import android.util.Log;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenterImpl;
import com.congxiaoyao.segmenterror.request.UserRequest;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.utils.TAG;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by congxiaoyao on 2016/8/24.
 */
public class PersonalDetailPresenter extends BasePresenterImpl<PersonalDetailContract.View> implements PersonalDetailContract.Presenter {

    public PersonalDetailPresenter(PersonalDetailContract.View view) {
        super(view);
    }

    @Override
    public void subscribe() {
        view.showLoading();

        //如果没有token直接显示未登录
        String token;
        if ((token = exceptionDispatcher
                .getTokenOrDispatchException(view.getContext())) == null) return;

        //真正开始拉数据
        Subscription subscribe = SERetrofit.create(UserRequest.class)
                .me(token)
                .compose(ResponsePreProcess::dataToBean)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(user -> {
                    view.showUserInfo(user);
                    view.hideLoading();
                }, exceptionDispatcher::dispatchException);
        subscriptions.add(subscribe);
    }

    @Override
    public void onDispatchException(Throwable throwable) {
        view.hideLoading();
        view.showEmpty();
        Log.d(TAG.ME, "onDispatchException: "+throwable);
    }

    @Override
    public boolean onUnLogin(String reason) {
        Toast.makeText(view.getContext(), "未登录", Toast.LENGTH_SHORT).show();
        return true;
    }

}