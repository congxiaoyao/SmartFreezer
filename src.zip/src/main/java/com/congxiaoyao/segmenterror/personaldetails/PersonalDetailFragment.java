package com.congxiaoyao.segmenterror.personaldetails;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.ContentLoadingProgressBar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.mvpbase.view.LoadableViewImpl;
import com.congxiaoyao.segmenterror.response.beans.User;
import com.squareup.picasso.Picasso;

/**
 * A simple {@link Fragment} subclass.
 */
public class PersonalDetailFragment extends LoadableViewImpl<PersonalDetailContract.Presenter>
        implements PersonalDetailContract.View,
        View.OnClickListener {

    private ImageView avatar;
    private TextView userName;
    private TextView sex;
    private TextView birthday;
    private TextView city;
    private TextView description;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_personal_detail, container, false);

        avatar = (ImageView) view.findViewById(R.id.iv_avatar);
        view.findViewById(R.id.ll_avatar).setOnClickListener(this);

        userName = (TextView) view.findViewById(R.id.tv_user_name);
        view.findViewById(R.id.ll_user_name).setOnClickListener(this);

        sex = (TextView) view.findViewById(R.id.tv_sex);
        view.findViewById(R.id.ll_sex).setOnClickListener(this);

        birthday = (TextView) view.findViewById(R.id.tv_birthday);
        view.findViewById(R.id.ll_birthday).setOnClickListener(this);

        city = (TextView) view.findViewById(R.id.tv_city);
        view.findViewById(R.id.ll_city).setOnClickListener(this);

        description = (TextView) view.findViewById(R.id.tv_description);
        view.findViewById(R.id.ll_description).setOnClickListener(this);

        progressBar = (ContentLoadingProgressBar) view.findViewById(R.id.content_loading_progress);
        showEmpty();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.subscribe();
    }

    @Override
    public void showUserInfo(User user) {
        userName.setText(user.getName());
        sex.setText(user.getGender() == 1 ? "男" : "女");
        birthday.setText(user.getBirthday());
        city.setText(user.getCityName());
        description.setText(user.getDescription());
        Picasso.with(getContext())
                .load(user.getAvatarUrl())
                .resize(avatar.getWidth(), avatar.getHeight())
                .placeholder(R.drawable.ic_avatar)
                .error(R.drawable.ic_avatar)
                .into(avatar);
    }

    @Override
    public void showEmpty() {
        userName.setText("");
        sex.setText("");
        birthday.setText("");
        city.setText("");
        description.setText("加载中...");
        avatar.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_avatar));
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(getContext(), "暂不开放编辑功能", Toast.LENGTH_SHORT).show();
    }

}
