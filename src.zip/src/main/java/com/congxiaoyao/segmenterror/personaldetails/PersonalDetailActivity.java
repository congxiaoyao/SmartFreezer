package com.congxiaoyao.segmenterror.personaldetails;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenter;
import com.congxiaoyao.segmenterror.mvpbase.view.BaseView;
import com.congxiaoyao.segmenterror.mvpbase.SimpleMvpActivity;

public class PersonalDetailActivity extends SimpleMvpActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public String getToolbarTitle() {
        return "个人详情";
    }

    @Override
    public BasePresenter getPresenter(BaseView baseView) {
        return new PersonalDetailPresenter((PersonalDetailContract.View) baseView);
    }

    @Override
    public Fragment getFragment() {
        return new PersonalDetailFragment();
    }
}
