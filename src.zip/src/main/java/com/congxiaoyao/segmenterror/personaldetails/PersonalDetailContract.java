package com.congxiaoyao.segmenterror.personaldetails;

import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenter;
import com.congxiaoyao.segmenterror.mvpbase.view.LoadableView;
import com.congxiaoyao.segmenterror.response.beans.User;

/**
 * Created by congxiaoyao on 2016/8/24.
 */
public class PersonalDetailContract {

    interface View extends LoadableView<Presenter> {

        void showUserInfo(User user);

        void showEmpty();
    }

    interface Presenter extends BasePresenter {

    }
}
