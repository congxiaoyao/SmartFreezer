package com.congxiaoyao.segmenterror.answersoutline;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.Me;
import com.congxiaoyao.segmenterror.mvpbase.presenter.ListLoadablePresenterImpl;
import com.congxiaoyao.segmenterror.questiondetail.QuestionDetailActivity;
import com.congxiaoyao.segmenterror.request.QuestionRequest;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.response.beans.AnsweredQuestion;
import com.congxiaoyao.segmenterror.response.beans.ResponseBean;
import com.congxiaoyao.segmenterror.response.exception.StatusException;
import com.congxiaoyao.segmenterror.utils.ActivityUtils;
import com.congxiaoyao.segmenterror.utils.TAG;

import java.util.ArrayList;
import java.util.List;

import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by congxiaoyao on 2016/8/27.
 */
public class AnswersOutlinePresenter extends ListLoadablePresenterImpl<AnswersOutlineFragment>
        implements IAnswersOutlinePresenter {

    public AnswersOutlinePresenter(AnswersOutlineFragment view) {
        super(view);
    }

    @Override
    public Observable<ResponsePagedListData<AnsweredQuestion>> pullPagedListData(int page) {
        long uid = getUid();
        Log.d(TAG.ME, "pullPagedListData: uid = " + uid);
        if (uid == -1) {
            Toast.makeText(view.getContext(), "请登录", Toast.LENGTH_SHORT).show();
            return null;
        }
        return SERetrofit.create(QuestionRequest.class)
                .getAnsweredQuestions(uid,
                        exceptionDispatcher.getTokenOrDispatchException(view.getContext()), page);
    }

    @Override
    public void onDispatchException(Throwable throwable) {
        super.onDispatchException(throwable);
    }

    @Override
    public void jumpToQuestion(Long id) {
        ActivityUtils.jumpToQuestion(view.getContext(), id);
    }

    private long getUid() {
        long uid = ((AnswersOutlineActivity) view.getActivity()).getUid();
        if (uid == -1) {
            Me me = Me.fromSharedPreferences(view.getContext());
            if (me.getId() == null) {
                return -1;
            }
            uid = Long.parseLong(me.getId());
        }
        return uid;
    }

    @Override
    public boolean onUnLogin(String reason) {
        view.showDataEmpty();
        Toast.makeText(view.getContext(), "请登录", Toast.LENGTH_SHORT).show();
        return true;
    }
}
