package com.congxiaoyao.segmenterror.answersoutline;

import android.view.View;

import com.chad.library.adapter.base.BaseViewHolder;
import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.mvpbase.view.SimpleListLoadableView;
import com.congxiaoyao.segmenterror.response.beans.AnsweredQuestion;

/**
 * Created by congxiaoyao on 2016/8/27.
 */
public class AnswersOutlineFragment
        extends SimpleListLoadableView<IAnswersOutlinePresenter, AnsweredQuestion> {

    @Override
    protected void convert(BaseViewHolder viewHolder, AnsweredQuestion data) {
        viewHolder.setText(R.id.tv_vote_count, data.getVotes() + "")
                .setText(R.id.tv_time, data.getCreatedDate())
                .setText(R.id.tv_question_title, data.getTitle())
                .setText(R.id.tv_outline, data.getExcerpt());
    }

    @Override
    protected int getPageSize() {
        return 20;
    }

    @Override
    protected int getItemLayoutResId() {
        return R.layout.item_my_answer;
    }

    @Override
    protected void onItemClicked(AnsweredQuestion question, View view) {
        presenter.jumpToQuestion(question.getQuestion().getId());
    }
}
