package com.congxiaoyao.segmenterror.answersoutline;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import com.congxiaoyao.segmenterror.Me;
import com.congxiaoyao.segmenterror.mvpbase.LoadableListActivity;
import com.congxiaoyao.segmenterror.mvpbase.presenter.ListLoadablePresenter;
import com.congxiaoyao.segmenterror.mvpbase.view.ListLoadableView;

/**
 * Created by congxiaoyao on 2016/8/27.
 */
public class AnswersOutlineActivity extends LoadableListActivity {

    public static final String EXTRA_UID = "EXTRA_UID";
    private long uid;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        uid = getIntent().getLongExtra(EXTRA_UID, -1);
        if (uid != -1) {
            String id = Me.fromSharedPreferences(this).getId();
            if (id == null || id.equals("")) {
                uid = -1;
                return;
            }
            uid = Long.parseLong(id);
        }
    }

    @Override
    public String getToolbarTitle() {
        return "回答";
    }

    @Override
    public ListLoadablePresenter getPresenter(ListLoadableView baseView) {
        return new AnswersOutlinePresenter((AnswersOutlineFragment) baseView);
    }

    @Override
    public Fragment getFragment() {
        return new AnswersOutlineFragment();
    }

    public long getUid() {
        return uid;
    }
}
