package com.congxiaoyao.segmenterror.answersoutline;

import com.congxiaoyao.segmenterror.mvpbase.presenter.ListLoadablePresenter;

/**
 * Created by congxiaoyao on 2016/8/27.
 */
public interface IAnswersOutlinePresenter extends ListLoadablePresenter {

    void jumpToQuestion(Long id);
}
