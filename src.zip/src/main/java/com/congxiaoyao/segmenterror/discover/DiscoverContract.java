package com.congxiaoyao.segmenterror.discover;

import android.content.Context;

import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenter;
import com.congxiaoyao.segmenterror.mvpbase.view.BaseView;


/**
 * Created by congxiaoyao on 2016/8/16.
 */
public interface DiscoverContract {

    interface View extends BaseView<Presenter> {
        Context getContext();
    }


    interface Presenter extends BasePresenter {
    }
}
