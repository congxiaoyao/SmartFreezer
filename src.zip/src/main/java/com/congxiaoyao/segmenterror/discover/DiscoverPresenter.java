package com.congxiaoyao.segmenterror.discover;

/**
 * Created by congxiaoyao on 2016/8/20.
 */
public class DiscoverPresenter implements DiscoverContract.Presenter {

    private DiscoverContract.View view;

    public DiscoverPresenter(DiscoverContract.View view) {
        this.view = view;
        view.setPresenter(this);
    }

    @Override
    public void subscribe() {

    }

    @Override
    public void unSubscribe() {

    }
}
