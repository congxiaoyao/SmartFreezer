package com.congxiaoyao.segmenterror.mvpbase.presenter;

/**
 * Created by congxiaoyao on 2016/8/16.
 */
public interface BasePresenter {

    void subscribe();

    void unSubscribe();
}
