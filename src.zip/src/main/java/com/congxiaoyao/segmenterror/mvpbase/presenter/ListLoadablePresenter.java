package com.congxiaoyao.segmenterror.mvpbase.presenter;

import com.congxiaoyao.segmenterror.response.beans.Page;

/**
 * Created by congxiaoyao on 2016/8/26.
 */
public interface ListLoadablePresenter extends BasePresenter {

    void savePage(Page page);

    boolean hasMoreData();

    void loadMoreData();

    void refreshData();
}
