package com.congxiaoyao.segmenterror.questiondetail;

import android.webkit.WebResourceResponse;
import android.webkit.WebView;

import com.congxiaoyao.segmenterror.helpers.QuestionBottomBarHelper;
import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenter;
import com.congxiaoyao.segmenterror.mvpbase.view.LoadableView;
import com.congxiaoyao.segmenterror.response.beans.Answer;
import com.congxiaoyao.segmenterror.response.beans.Question;

import java.util.List;

/**
 * Created by congxiaoyao on 2016/9/6.
 */
public interface QuestionDetailContract {

    interface View extends LoadableView<Presenter> {

        WebView getWebView();

        QuestionBottomBarHelper getBottomBarHelper();

        void showQuestion(Question question, Long id);

        void showAnswers(List<Answer> answers);

        void showEmptyPage();
    }

    interface Presenter extends BasePresenter {

        WebResourceResponse loadImage(String url);
    }

}
