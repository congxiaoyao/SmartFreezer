package com.congxiaoyao.segmenterror.questiondetail;

import android.util.Log;
import android.webkit.WebResourceResponse;

import com.congxiaoyao.segmenterror.mvpbase.presenter.BasePresenterImpl;
import com.congxiaoyao.segmenterror.request.AnswerRequest;
import com.congxiaoyao.segmenterror.request.QuestionRequest;
import com.congxiaoyao.segmenterror.request.okhttp.MyOkHttp;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.utils.TAG;

import java.io.IOException;
import java.io.InputStream;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by congxiaoyao on 2016/9/7.
 */
public class QuestionDetailPresenter extends BasePresenterImpl<QuestionDetailContract.View>
        implements QuestionDetailContract.Presenter {

    private static final Long TEST_ID = 1010000004884930L;
    private Long id;

    public QuestionDetailPresenter(QuestionDetailContract.View view, Long questionId) {
        super(view);
        this.id = questionId;
    }

    @Override
    public void subscribe() {
        view.showEmptyPage();
        SERetrofit.create(QuestionRequest.class)
                .detail(id, exceptionDispatcher.getTokenOrDispatchException(view.getContext()))
                .compose(ResponsePreProcess::dataToBean)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(question -> {
                    view.showQuestion(question, id);
                    subscribeAnswers();
                }, exceptionDispatcher::dispatchException);
    }

    public void subscribeAnswers() {
        SERetrofit.create(AnswerRequest.class)
                .getAnswers(id, exceptionDispatcher.getTokenOrDispatchException(view.getContext()))
                .compose(ResponsePreProcess::listDataToBeanList)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(view::showAnswers, exceptionDispatcher::dispatchException);
    }

    @Override
    public WebResourceResponse loadImage(String url) {
        Log.d(TAG.ME, "loadImage: url = " + url);
        OkHttpClient okHttp = MyOkHttp.getInstance();
        Request request = new Request.Builder().url(url).build();
        try {
            Response response = okHttp.newCall(request).execute();
            InputStream byteStream = response.body().byteStream();
            return new WebResourceResponse(response.header("Content-Type"),
                    response.header("Content-Encoding"), byteStream);
        } catch (IOException e) {
            exceptionDispatcher.dispatchException(e);
        }
        return null;
    }

    @Override
    public boolean onNullDataError(String msg) {
        view.showAnswers(null);
        return true;
    }
}
