package com.congxiaoyao.segmenterror.questiondetail;

import android.annotation.TargetApi;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.helpers.BottomBarHelper;
import com.congxiaoyao.segmenterror.helpers.QuestionBottomBarHelper;
import com.congxiaoyao.segmenterror.helpers.SharedToolbarHelper;
import com.congxiaoyao.segmenterror.mvpbase.view.LoadableViewImpl;
import com.congxiaoyao.segmenterror.request.gson.GsonHelper;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.beans.Answer;
import com.congxiaoyao.segmenterror.response.beans.Question;
import com.congxiaoyao.segmenterror.utils.TAG;
import com.congxiaoyao.segmenterror.utils.VersionUtils;
import com.google.gson.reflect.TypeToken;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * Created by congxiaoyao on 2016/9/6.
 */
public class QuestionDetailFragment
        extends LoadableViewImpl<QuestionDetailContract.Presenter>
        implements QuestionDetailContract.View {

    private WebView webView;
    private Toolbar toolbar;
    private SharedToolbarHelper toolbarHelper;
    private BottomBarHelper bottomBarHelper;
    private SwipeRefreshLayout swipeRefreshLayout;

    private Queue<Runnable> loadingQueue;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_question_detail, container, false);

        loadingQueue = new LinkedList<>();

        //得到几个重要的对象
        webView = (WebView) root.findViewById(R.id.webview);
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new MyWebViewClient());
        webView.addJavascriptInterface(new SEJavaScriptInterface(), "sf");

        toolbar = (Toolbar) root.findViewById(R.id.toolbar);
        bottomBarHelper = new QuestionBottomBarHelper(root.findViewById(R.id.bottom_bar));
        swipeRefreshLayout = (SwipeRefreshLayout) root.findViewById(R.id.swipe_refresh_layout);

        //初始化webview
        //初始化toolbar
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("问题");
        //初始化bottombar
        //初始化swipeRefreshLayout
        swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(getContext(),
                R.color.colorLightGreen));
        swipeRefreshLayout.setOnRefreshListener(()->{
            swipeRefreshLayout.setRefreshing(false);
        });

        presenter.subscribe();
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        toolbarHelper = new SharedToolbarHelper(toolbar, R.menu.fixed_share);
    }

    @Override
    public WebView getWebView() {
        return webView;
    }

    @Override
    public QuestionBottomBarHelper getBottomBarHelper() {
        return null;
    }

    @Override
    public void showQuestion(Question question, Long id) {
        String json = GsonHelper.getInstance().toJson(question);
        StringBuilder builder = new StringBuilder("javascript:showQuestion(");
        builder.append(json).append(", \"").append(id).append("\")");
        String script = builder.toString();
        submitAndRun(() -> runJavaScript(script));
    }

    @Override
    public void showAnswers(List<Answer> answers) {
        if (answers == null) {
            submitAndRun(() -> {});
            return;
        }
        Collections.sort(answers, (answers1, answers2) ->
                answers1.getType().equals(Answer.TYPE_ACCEPTED) ?
                        -1 : answers2.getType().equals(Answer.TYPE_ACCEPTED) ? 1 : 0);
        String script = "javascript:showAnswers(" +
                GsonHelper.getInstance().toJson(answers, new TypeToken<List<Answer>>() {
                }.getType()) + ")";
        submitAndRun(() -> runJavaScript(script));
    }

    @Override
    public void showEmptyPage() {
        if (webView == null) {
            throw new RuntimeException("WebView has not been initialized");
        }
        webView.loadUrl("file:///android_asset/question.html");
    }

    //TODO 在4.4之前的机器上验证下直接loadUrl的可行性
    @TargetApi(Build.VERSION_CODES.KITKAT)
    private void runJavaScript(String javaScript) {
        if (VersionUtils.KitKatAndPlus) {
            webView.evaluateJavascript(javaScript, null);
        } else {
            webView.loadUrl(javaScript);
        }
    }

    private void submitAndRun(Runnable runnable) {
        synchronized (loadingQueue) {
            loadingQueue.offer(runnable);
            int size = loadingQueue.size();
            if (size != 3) return;
        }
        Runnable r;
        while ((r = loadingQueue.poll()) != null) {
            r.run();
        }
    }

    private class SEJavaScriptInterface {

        @JavascriptInterface
        public void answerAction(String str, String str2, String str3) {
            Toast.makeText(getContext(),
                    "answerAction param1 = " + str + " param2 = " + str2 + " param3 = " + str3,
                    Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface
        public void archive(String str) {
            Toast.makeText(getContext(),
                    "archive param1 = " + str ,
                    Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface
        public void follow(String str) {
            Toast.makeText(getContext(),
                    "follow param1 = " + str ,
                    Toast.LENGTH_SHORT).show();
        }

        /**
         * 点like或dislike的回调
         * @param str
         * @param str2
         */
        @JavascriptInterface
        public void questionAction(String str, String str2) {
            Toast.makeText(getContext(),
                    "questionAction param1 = " + str + " param2 = " + str2 ,
                    Toast.LENGTH_SHORT).show();

        }

        @JavascriptInterface
        public void showAnswerMoreDialog(String str, String str2) {
            Toast.makeText(getContext(),
                    "showAnswerMoreDialog param1 = " + str + " param2 = " + str2 ,
                    Toast.LENGTH_SHORT).show();

        }

        /**
         * 评论按钮
         * @param str
         * @param str2
         */
        @JavascriptInterface
        public void showComments(String str, String str2) {
            Toast.makeText(getContext(),
                    "showComments param1 = " + str + " param2 = " + str2,
                    Toast.LENGTH_SHORT).show();
        }

        /**
         * 最右边的三个小点
         * @param str
         * @param str2
         */
        @JavascriptInterface
        public void showMore(String str, String str2) {
            Toast.makeText(getContext(),
                    "showMore param1 = " + str + " param2 = " + str2 ,
                    Toast.LENGTH_SHORT).show();


        }

        @JavascriptInterface
        public void unfollow(String str) {
            Toast.makeText(getContext(),
                    "unfollow param1 = " + str ,
                    Toast.LENGTH_SHORT).show();

        }

        /**
         * 点击图片的回调
         * @param str
         */
        @JavascriptInterface
        public void viewImage(String str) {
            Toast.makeText(getContext(),
                    "viewImage param1 = " + str ,
                    Toast.LENGTH_SHORT).show();

        }
    }

    private class MyWebViewClient extends WebViewClient {

        private WebResourceResponse loadImage(String url) {
            return presenter.loadImage(url);
        }

        @Override
        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            Log.d(TAG.ME, "onPageFinished: str = " + str);
            submitAndRun(() -> {});
        }


        public WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
            Log.d(TAG.ME, "shouldInterceptRequest: old str = " + str);
            return str.indexOf("file:///img/") == 0 ?
                    loadImage("http://www.segmentfault.com/" + str.substring(8)) : null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.d(TAG.ME, "shouldOverrideUrlLoading: url = " + url);
            Toast.makeText(getContext(), "url = " + url, Toast.LENGTH_SHORT).show();
            return true;
        }
    }
}