package com.congxiaoyao.segmenterror.questionlist;

import com.congxiaoyao.segmenterror.mvpbase.presenter.ListLoadablePresenter;

/**
 * Created by congxiaoyao on 2016/9/2.
 */
public interface IQuestionPresenter extends ListLoadablePresenter {

    void changeToUnAnswered();

    void changeToHottest();

    void changeToNewest();

    void jumpToQuestion(Long id);
}
