package com.congxiaoyao.segmenterror.questionlist;

import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseViewHolder;
import com.congxiaoyao.segmenterror.R;
import com.congxiaoyao.segmenterror.mvpbase.view.SimpleListLoadableView;
import com.congxiaoyao.segmenterror.response.beans.Question;

public class QuestionListFragment extends SimpleListLoadableView<IQuestionPresenter, Question> {

    @Override
    protected int getPageSize() {
        return 30;
    }

    @Override
    protected void convert(BaseViewHolder viewHolder, Question data) {
        View leftHint = viewHolder.getView(R.id.ll_question_left_hint);
        setupLeftHint(data, leftHint);
        viewHolder.setText(R.id.tv_user_name, data.getUser().getName())
                .setText(R.id.tv_question_title, data.getTitle())
                .setText(R.id.tv_time, data.getCreatedDate());
    }

    @Override
    protected int getItemLayoutResId() {
        return R.layout.item_question_outline;
    }

    private void setupLeftHint(Question question, View leftHint) {
        TextView answerCountTv = (TextView) leftHint.findViewById(R.id.tv_answer_count);
        TextView questionStateTv = (TextView) leftHint.findViewById(R.id.tv_question_state);

        int red = ContextCompat.getColor(getContext(), R.color.colorRed);
        int green = ContextCompat.getColor(getContext(), R.color.colorLightGreen);
        int gray = Color.rgb(128, 139, 135);

        boolean isAccept = question.isAccepted();
        int answerCount = question.getAnswers();

        questionStateTv.setText("回答");
        if (answerCount == 0) {
            leftHint.setBackgroundColor(red);
        } else if (isAccept) {
            leftHint.setBackgroundColor(gray);
            questionStateTv.setText("解决");
        } else {
            leftHint.setBackgroundColor(green);
        }
        answerCountTv.setText(answerCount + "");
    }

    @Override
    protected void onItemClicked(Question question, View view) {
        presenter.jumpToQuestion(question.getId());
    }
}
