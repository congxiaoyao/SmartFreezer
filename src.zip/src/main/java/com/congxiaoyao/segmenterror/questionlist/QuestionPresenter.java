package com.congxiaoyao.segmenterror.questionlist;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.congxiaoyao.segmenterror.Me;
import com.congxiaoyao.segmenterror.mvpbase.presenter.ListLoadablePresenterImpl;
import com.congxiaoyao.segmenterror.questiondetail.QuestionDetailActivity;
import com.congxiaoyao.segmenterror.request.QuestionRequest;
import com.congxiaoyao.segmenterror.request.retrofit2.SERetrofit;
import com.congxiaoyao.segmenterror.response.ResponsePagedListData;
import com.congxiaoyao.segmenterror.response.ResponsePreProcess;
import com.congxiaoyao.segmenterror.response.beans.Question;
import com.congxiaoyao.segmenterror.response.beans.ResponseBean;
import com.congxiaoyao.segmenterror.utils.ActivityUtils;
import com.congxiaoyao.segmenterror.utils.TAG;

import java.util.ArrayList;
import java.util.List;

import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by congxiaoyao on 2016/9/2.
 */
public class QuestionPresenter
        extends ListLoadablePresenterImpl<QuestionListFragment>
        implements IQuestionPresenter {

    private static final int TYPE_NEWEST = 0;
    private static final int TYPE_HOTTEST = 1;
    private static final int TYPE_UNANSWERED = 2;

    private int currentType = 0;
    private boolean isLoading = false;

    public QuestionPresenter(QuestionListFragment view) {
        super(view);
    }

    @Override
    public Observable<ResponsePagedListData<Question>> pullPagedListData(int page) {
        return createRequestByType(page);
    }

    @Override
    public void changeToUnAnswered() {
        if (currentType == TYPE_UNANSWERED) return;
        currentType = TYPE_UNANSWERED;
        subscribeByCurrentType();
    }

    @Override
    public void changeToHottest() {
        if (currentType == TYPE_HOTTEST) return;
        currentType = TYPE_HOTTEST;
        subscribeByCurrentType();
    }

    @Override
    public void changeToNewest() {
        if (currentType == TYPE_NEWEST) return;
        currentType = TYPE_NEWEST;
        subscribeByCurrentType();
    }

    private void subscribeByCurrentType() {
        if (isLoading) return;
        view.showLoading();
        Subscription subscription = createRequestByType(1)
                .compose(ResponsePreProcess.pagedListDataToBeanList(this::savePage))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(list -> {
                    view.showNothing();
                    view.addData(list);
                    view.hideLoading();
                    isLoading = false;
                }, exceptionDispatcher::dispatchException);
        subscriptions.add(subscription);
        isLoading = true;
    }

    @Override
    public void jumpToQuestion(Long id) {
        ActivityUtils.jumpToQuestion(view.getContext(), id);
    }

    /**
     * 根据当前的类型请求数据 返回observable对象，只是单纯的observable，并不包括后续处理
     * @param requestPage
     * @return
     */
    private Observable<ResponsePagedListData<Question>> createRequestByType(int requestPage) {
        QuestionRequest request = SERetrofit.create(QuestionRequest.class);
        Observable<ResponsePagedListData<Question>> observable = null;
        String token = exceptionDispatcher.getTokenOrDispatchException(view.getContext());
        //当前的种类正常下有三种 TYPE_NEWEST TYPE_HOTTEST TYPE_UNANSWERED
        //根据不同的种类返回不同的Observable
        switch (currentType) {
            case TYPE_NEWEST:
                observable = request.getNewestQuestions(requestPage, token);
                break;
            case TYPE_HOTTEST:
                observable = request.getHottestQuestions(requestPage, token);
                break;
            case TYPE_UNANSWERED:
                observable = request.getUnAnsweredQuestions(requestPage, token);
                break;
            default:
                throw new RuntimeException("current state error");
        }
        return observable;
    }

    @Override
    public void onDispatchException(Throwable throwable) {
        super.onDispatchException(throwable);
    }
}