package com.congxiaoyao.segmenterror.behaviors;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.support.design.widget.CoordinatorLayout;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

/**
 * Created by congxiaoyao on 2016/7/29.
 */
public class FabBehavior extends CoordinatorLayout.Behavior {

    private static final String TAG = "cxy";
    private int transDis = 0;
    private boolean isRunning = false;
    private boolean canLayout = true;
    private RunningListener listener = new RunningListener();

    public FabBehavior(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout,
                                       View child, View directTargetChild, View target,
                                       int nestedScrollAxes) {
        canLayout = false;
        return true;
    }

    @Override
    public void onNestedScroll(CoordinatorLayout coordinatorLayout,
                               View child, View target,
                               int dxConsumed, int dyConsumed,
                               int dxUnconsumed, int dyUnconsumed) {
        if (dyConsumed == 0 || isRunning) return;
        if (dyConsumed < 0 && child.getTranslationY() != transDis) {
            child.animate().translationY(transDis).setDuration(200).setListener(listener).start();
        } else if (dyConsumed > 0 && child.getTranslationY() != 0) {
            child.animate().translationY(0).setDuration(200).setListener(listener).start();
        }
    }

    @Override
    public boolean onLayoutChild(CoordinatorLayout parent, View child, int layoutDirection) {
        if (canLayout) {
            child.setTranslationY(transDis = parent.getBottom() - child.getTop());
            child.setTag(transDis);
        }
        return super.onLayoutChild(parent, child, layoutDirection);
    }

    class RunningListener extends AnimatorListenerAdapter {
        @Override
        public void onAnimationStart(Animator animation) {
            isRunning = true;
        }

        @Override
        public void onAnimationEnd(Animator animation) {
            isRunning = false;
        }

        @Override
        public void onAnimationCancel(Animator animation) {
            isRunning = false;
        }
    }

}
