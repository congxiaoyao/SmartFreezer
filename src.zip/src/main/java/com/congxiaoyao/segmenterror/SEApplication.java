package com.congxiaoyao.segmenterror;

import android.app.Application;
import android.util.Log;

import com.congxiaoyao.segmenterror.request.okhttp.MyOkHttp;

/**
 * Created by congxiaoyao on 2016/8/22.
 */
public class SEApplication extends Application {

    @Override
    public void onCreate() {
        MyOkHttp.setContext(this);
        super.onCreate();
    }

    @Override
    public void onTerminate() {
        Log.d("cxy", "onTerminate: ");
        MyOkHttp.release();
        super.onTerminate();
    }
}
